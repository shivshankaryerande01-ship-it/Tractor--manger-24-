package com.tractormanager.app.core

import com.tractormanager.app.core.geo.GeoPoint
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ValidatorsTest {

    private val triangle = listOf(
        GeoPoint(18.50, 73.80),
        GeoPoint(18.50, 73.81),
        GeoPoint(18.51, 73.805)
    )

    @Test
    fun `valid farmer passes`() {
        val result = Validators.farmer("रामराव पाटील", "9876543210")
        assertTrue(result.isValid)
    }

    @Test
    fun `farmer name is required`() {
        val result = Validators.farmer("  ", "9876543210")
        assertFalse(result.isValid)
        assertNotNull(result.error("name"))
    }

    @Test
    fun `mobile must be ten digits starting with 6 to 9`() {
        assertNotNull(Validators.farmer("राम", "1234567890").error("mobile"))
        assertNotNull(Validators.farmer("राम", "98765").error("mobile"))
        assertNotNull(Validators.farmer("राम", "5876543210").error("mobile"))
        assertNull(Validators.farmer("राम", "6876543210").error("mobile"))
    }

    @Test
    fun `land field needs three valid non crossing points`() {
        val result = Validators.landField("शिवार", triangle, 8000.0, "पुणे")
        assertTrue(result.isValid)
    }

    @Test
    fun `land field rejects too few points`() {
        val result = Validators.landField("शिवार", triangle.take(2), 8000.0)
        assertFalse(result.isValid)
        assertNotNull(result.error("points"))
    }

    @Test
    fun `land field rejects tiny area`() {
        val result = Validators.landField("शिवार", triangle, 0.5)
        assertFalse(result.isValid)
        assertNotNull(result.error("area"))
    }

    @Test
    fun `land field rejects crossing boundary`() {
        val bowTie = listOf(
            GeoPoint(18.50, 73.80),
            GeoPoint(18.51, 73.81),
            GeoPoint(18.51, 73.80),
            GeoPoint(18.50, 73.81)
        )
        val result = Validators.landField("शिवार", bowTie, 8000.0)
        assertFalse(result.isValid)
        assertNotNull(result.error("points"))
    }

    @Test
    fun `work record requires farmer field type acres and rate`() {
        assertTrue(Validators.workRecord("f1", "l1", "नांगरणी", 2.0, 1200.0).isValid)
        assertNotNull(Validators.workRecord("", "l1", "नांगरणी", 2.0, 1200.0).error("farmer"))
        assertNotNull(Validators.workRecord("f1", "", "नांगरणी", 2.0, 1200.0).error("field"))
        assertNotNull(Validators.workRecord("f1", "l1", "", 2.0, 1200.0).error("workType"))
        assertNotNull(Validators.workRecord("f1", "l1", "नांगरणी", 0.0, 1200.0).error("acres"))
        assertNotNull(Validators.workRecord("f1", "l1", "नांगरणी", 2.0, -1.0).error("rate"))
    }

    @Test
    fun `payment requires farmer and positive amount`() {
        assertTrue(Validators.payment("f1", 500.0).isValid)
        assertNotNull(Validators.payment("", 500.0).error("farmer"))
        assertNotNull(Validators.payment("f1", 0.0).error("amount"))
        assertNotNull(Validators.payment("f1", null).error("amount"))
    }

    @Test
    fun `pin must be four to six digits`() {
        assertTrue(Validators.pin("1234").isValid)
        assertTrue(Validators.pin("123456").isValid)
        assertFalse(Validators.pin("12").isValid)
        assertFalse(Validators.pin("1234567").isValid)
        assertFalse(Validators.pin("12a4").isValid)
    }

    @Test
    fun `pin confirmation must match`() {
        val result = Validators.pin("1234", "4321")
        assertFalse(result.isValid)
        assertEquals("दोन्ही PIN जुळत नाहीत.", result.error("confirmPin"))
    }

    @Test
    fun `sync url must be https when provided`() {
        assertTrue(Validators.syncSettings("", "").isValid)
        assertTrue(Validators.syncSettings("https://abc.firebasedatabase.app", "घर").isValid)
        assertNotNull(
            Validators.syncSettings("http://abc.firebasedatabase.app", "घर").error("url")
        )
        assertNotNull(Validators.syncSettings("https://abc.firebasedatabase.app", "").error("code"))
    }
}
