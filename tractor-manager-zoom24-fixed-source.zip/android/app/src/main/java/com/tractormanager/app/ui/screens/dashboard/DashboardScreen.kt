package com.tractormanager.app.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Agriculture
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tractormanager.app.core.DateUtils
import com.tractormanager.app.core.Money
import com.tractormanager.app.core.NumberText
import com.tractormanager.app.ui.appViewModel
import com.tractormanager.app.ui.components.EmptyState
import com.tractormanager.app.ui.components.FarmerListCard
import com.tractormanager.app.ui.components.ScreenScaffold
import com.tractormanager.app.ui.components.SectionHeader
import com.tractormanager.app.ui.components.StatCard
import com.tractormanager.app.ui.components.WorkListCard
import com.tractormanager.app.ui.theme.Danger
import com.tractormanager.app.ui.theme.Green600
import com.tractormanager.app.ui.theme.Green700
import com.tractormanager.app.ui.theme.Green900
import com.tractormanager.app.ui.theme.InkSoft
import com.tractormanager.app.ui.theme.Mustard
import com.tractormanager.app.ui.theme.White
import java.time.LocalDate

@Composable
fun DashboardScreen(
    onAddWork: () -> Unit,
    onAddFarmer: () -> Unit,
    onMeasureLand: () -> Unit,
    onShowFarmers: () -> Unit,
    onShowWork: () -> Unit,
    onShowPayments: () -> Unit,
    onShowReports: () -> Unit,
    onSettings: () -> Unit,
    onFarmerClick: (String) -> Unit,
    onWorkClick: (String) -> Unit
) {
    val viewModel = appViewModel { DashboardViewModel(it.dashboardRepository) }
    val data by viewModel.data.collectAsStateWithLifecycle()
    val today = DateUtils.todayEpochDay()

    ScreenScaffold(
        title = "ट्रॅक्टर मॅनेजर",
        subtitle = "${DateUtils.formatWeekday(today)}, ${DateUtils.formatDate(today)}",
        actions = {
            IconButton(onClick = onSettings) {
                Icon(Icons.Outlined.Settings, contentDescription = "सेटिंग्ज")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(listOf(Green700, Green600)),
                        RoundedCornerShape(24.dp)
                    )
                    .padding(20.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "आजचे उत्पन्न",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.9f),
                            modifier = Modifier.weight(1f)
                        )
                        Surface(
                            color = Color.White.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                "आज",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        Money.format(data.todayWork.amount),
                        style = MaterialTheme.typography.displaySmall,
                        color = Color.White
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "${data.todayWork.workCount} कामे • ${NumberText.format(data.todayWork.acres, 2)} एकर",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.92f)
                    )
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        HeroPill(
                            "या महिन्याचे ${Money.format(data.monthWork.amount)}",
                            Modifier.weight(1f)
                        )
                        HeroPill(
                            "जमा ${Money.format(data.monthReceived)}",
                            Modifier.weight(1f)
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickAction(
                    label = "नवीन काम",
                    icon = Icons.Outlined.Add,
                    onClick = onAddWork,
                    modifier = Modifier.weight(1f)
                )
                QuickAction(
                    label = "शेतकरी जोडा",
                    icon = Icons.Outlined.PersonAdd,
                    onClick = onAddFarmer,
                    modifier = Modifier.weight(1f)
                )
                QuickAction(
                    label = "जमीन मोजा",
                    icon = Icons.Outlined.Map,
                    onClick = onMeasureLand,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(18.dp))
            Text(
                "आजचा हिशोब",
                style = MaterialTheme.typography.titleMedium,
                color = Green900
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard(
                    label = "या महिन्याचे उत्पन्न",
                    value = Money.format(data.monthWork.amount),
                    note = "${data.monthWork.workCount} कामे",
                    icon = Icons.Outlined.TrendingUp,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    label = "या महिन्यात जमा",
                    value = Money.format(data.monthReceived),
                    icon = Icons.Outlined.Payments,
                    tint = Green600,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard(
                    label = "एकूण बाकी",
                    value = Money.format(data.pendingTotal),
                    note = "वसूली बाकी",
                    icon = Icons.Outlined.AccountBalanceWallet,
                    tint = Danger,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    label = "शेतकरी",
                    value = data.farmerCount.toString(),
                    note = "नोंदवलेले",
                    icon = Icons.Outlined.Groups,
                    tint = Mustard,
                    modifier = Modifier.weight(1f)
                )
            }

            SectionHeader(
                title = "अलीकडील काम",
                actionLabel = "सर्व पहा",
                onAction = onShowWork
            )
            if (data.recentWork.isEmpty()) {
                EmptyState(
                    title = "अजून कामाची नोंद नाही",
                    message = "ट्रॅक्टरचे पहिले काम नोंदवून हिशोब सुरू करा.",
                    icon = Icons.Outlined.Agriculture,
                    actionLabel = "काम नोंदवा",
                    onAction = onAddWork
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    data.recentWork.take(4).forEach { row ->
                        WorkListCard(
                            row = row,
                            onClick = { onWorkClick(row.work.farmerId) }
                        )
                    }
                }
            }

            SectionHeader(
                title = "बाकी असलेले शेतकरी",
                actionLabel = "सर्व शेतकरी",
                onAction = onShowFarmers
            )
            if (data.pendingFarmers.isEmpty()) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = com.tractormanager.app.ui.theme.Green50,
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        "सर्व शेतकऱ्यांचे पैसे जमा आहेत. छान!",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        color = Green900
                    )
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    data.pendingFarmers.forEach { item ->
                        FarmerListCard(item = item, onClick = { onFarmerClick(item.farmer.id) })
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallLink("पैसे", Icons.Outlined.Payments, onShowPayments, Modifier.weight(1f))
                SmallLink("अहवाल", Icons.Outlined.TrendingUp, onShowReports, Modifier.weight(1f))
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}

@Composable
private fun HeroPill(text: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = Color.White.copy(alpha = 0.16f),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            style = MaterialTheme.typography.bodySmall,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun QuickAction(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        color = White,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            com.tractormanager.app.ui.theme.Border
        )
    ) {
        Column(
            modifier = Modifier.padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier
                    .size(38.dp)
                    .background(com.tractormanager.app.ui.theme.Green50, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = Green700, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.height(7.dp))
            Text(
                label,
                style = MaterialTheme.typography.labelMedium,
                color = Green900,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SmallLink(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = White,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            com.tractormanager.app.ui.theme.Border
        ),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = Green700, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(label, style = MaterialTheme.typography.labelLarge, color = Green900)
        }
    }
}
