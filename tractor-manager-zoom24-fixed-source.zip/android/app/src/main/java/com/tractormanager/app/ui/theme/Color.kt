package com.tractormanager.app.ui.theme

import androidx.compose.ui.graphics.Color

val Green700 = Color(0xFF2E7D32)
val Green600 = Color(0xFF43A047)
val Green500 = Color(0xFF4CAF50)
val Green100 = Color(0xFFD7EFD8)
val Green50 = Color(0xFFEDF7ED)
val Green900 = Color(0xFF103B14)
val Mustard = Color(0xFFF9A825)
val MustardLight = Color(0xFFFFF3D6)
val Ink = Color(0xFF17251A)
val InkSoft = Color(0xFF50604F)
val Cloud = Color(0xFFF5F8F4)
val Border = Color(0xFFDCE5DA)
val White = Color(0xFFFFFFFF)
val Danger = Color(0xFFB3261E)
val DangerLight = Color(0xFFFDECEA)
val Info = Color(0xFF1565C0)
val InfoLight = Color(0xFFE7F0FB)
