package com.tractormanager.app.data.backup

import com.tractormanager.app.data.local.Farmer
import com.tractormanager.app.data.local.LandField
import com.tractormanager.app.data.local.Payment
import com.tractormanager.app.data.local.WorkRecord
import com.tractormanager.app.data.local.WorkTypeRate
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class BackupPayload(
    val schemaVersion: Int = SCHEMA_VERSION,
    val exportedAt: Long = 0L,
    val farmers: List<Farmer> = emptyList(),
    val fields: List<LandField> = emptyList(),
    val workRecords: List<WorkRecord> = emptyList(),
    val payments: List<Payment> = emptyList(),
    val workTypes: List<WorkTypeRate> = emptyList()
) {
    companion object {
        const val SCHEMA_VERSION = 1
    }
}

@Serializable
data class ImportSummary(
    val farmers: Int,
    val fields: Int,
    val workRecords: Int,
    val payments: Int
)

object BackupCodec {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        prettyPrint = true
    }

    fun encode(payload: BackupPayload): String = json.encodeToString(payload)

    fun decode(raw: String): Result<BackupPayload> = runCatching {
        val payload = json.decodeFromString<BackupPayload>(raw)
        require(payload.schemaVersion == BackupPayload.SCHEMA_VERSION) {
            "बॅकअप आवृत्ती जुळत नाही."
        }
        payload
    }
}

/**
 * Deterministic last-write-wins merge used by both restore and Firebase sync.
 * Farmer records duplicated across devices by mobile number are collapsed and
 * child records are re-pointed to the surviving farmer id.
 */
object DataMerger {

    fun merge(local: BackupPayload, remote: BackupPayload): BackupPayload {
        val farmerById = LinkedHashMap<String, Farmer>()
        remote.farmers.forEach { farmerById[it.id] = it }
        local.farmers.forEach { localFarmer ->
            val remoteFarmer = farmerById[localFarmer.id]
            if (remoteFarmer == null || localFarmer.updatedAt >= remoteFarmer.updatedAt) {
                farmerById[localFarmer.id] = localFarmer
            }
        }

        val farmerIdRemap = mutableMapOf<String, String>()
        val survivingFarmers = mutableListOf<Farmer>()
        farmerById.values.groupBy { it.mobile }.forEach { (_, group) ->
            val winner = group.maxWithOrNull(
                compareBy<Farmer> { it.updatedAt }.thenBy { if (it.isDeleted) 0 else 1 }
            ) ?: return@forEach
            survivingFarmers.add(winner)
            group.forEach { farmerIdRemap[it.id] = winner.id }
        }

        val fieldById = LinkedHashMap<String, LandField>()
        remote.fields.forEach { fieldById[it.id] = it }
        local.fields.forEach { localField ->
            val remoteField = fieldById[localField.id]
            if (remoteField == null || localField.updatedAt >= remoteField.updatedAt) {
                fieldById[localField.id] = localField
            }
        }
        val fields = fieldById.values.mapNotNull { field ->
            val mappedFarmer = farmerIdRemap[field.farmerId] ?: return@mapNotNull null
            field.copy(farmerId = mappedFarmer)
        }
        val fieldIdRemap = fields.associate { it.id to it.id }

        val workById = LinkedHashMap<String, WorkRecord>()
        remote.workRecords.forEach { workById[it.id] = it }
        local.workRecords.forEach { localWork ->
            val remoteWork = workById[localWork.id]
            if (remoteWork == null || localWork.updatedAt >= remoteWork.updatedAt) {
                workById[localWork.id] = localWork
            }
        }
        val works = workById.values.mapNotNull { work ->
            val mappedFarmer = farmerIdRemap[work.farmerId] ?: return@mapNotNull null
            val mappedField = work.fieldId?.let { fieldIdRemap[it] }
            work.copy(farmerId = mappedFarmer, fieldId = mappedField)
        }

        val paymentById = LinkedHashMap<String, Payment>()
        remote.payments.forEach { paymentById[it.id] = it }
        local.payments.forEach { localPayment ->
            val remotePayment = paymentById[localPayment.id]
            if (remotePayment == null || localPayment.updatedAt >= remotePayment.updatedAt) {
                paymentById[localPayment.id] = localPayment
            }
        }
        val payments = paymentById.values.mapNotNull { payment ->
            val mappedFarmer = farmerIdRemap[payment.farmerId] ?: return@mapNotNull null
            payment.copy(farmerId = mappedFarmer)
        }

        val typeById = LinkedHashMap<String, WorkTypeRate>()
        remote.workTypes.forEach { typeById[it.id] = it }
        local.workTypes.forEach { typeById[it.id] = it }

        return BackupPayload(
            schemaVersion = BackupPayload.SCHEMA_VERSION,
            exportedAt = System.currentTimeMillis(),
            farmers = survivingFarmers,
            fields = fields,
            workRecords = works,
            payments = payments,
            workTypes = typeById.values.toList()
        )
    }
}
