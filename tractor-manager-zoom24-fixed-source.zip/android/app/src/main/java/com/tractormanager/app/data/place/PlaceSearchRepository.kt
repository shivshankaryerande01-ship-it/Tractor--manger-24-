package com.tractormanager.app.data.place

import com.tractormanager.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class PlaceResult(
    val name: String,
    val displayName: String,
    val latitude: Double,
    val longitude: Double
)

class PlaceSearchRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    suspend fun search(query: String): Result<List<PlaceResult>> = withContext(Dispatchers.IO) {
        val trimmed = query.trim()
        if (trimmed.length < 2) {
            return@withContext Result.failure(
                IllegalArgumentException("किमान २ अक्षरे टाकून गाव किंवा ठिकाण शोधा.")
            )
        }
        runCatching {
            val encoded = URLEncoder.encode(trimmed, "UTF-8")
            val url = "https://nominatim.openstreetmap.org/search" +
                "?q=$encoded&format=json&limit=6&countrycodes=in&accept-language=mr,en"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "TractorManager/${BuildConfig.VERSION_NAME} (Android)")
                .header("Accept", "application/json")
                .get()
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("शोध सेवा उपलब्ध नाही (HTTP ${response.code}).")
                }
                val body = response.body?.string().orEmpty()
                val array = JSONArray(body)
                val results = mutableListOf<PlaceResult>()
                for (index in 0 until array.length()) {
                    val item = array.getJSONObject(index)
                    val lat = item.optString("lat").toDoubleOrNull() ?: continue
                    val lon = item.optString("lon").toDoubleOrNull() ?: continue
                    val display = item.optString("display_name")
                    val name = display.substringBefore(',').ifBlank { trimmed }
                    results.add(PlaceResult(name, display, lat, lon))
                }
                results
            }
        }.recoverCatching { error ->
            if (error is IOException) {
                throw IOException("इंटरनेट कनेक्शन तपासा. ठिकाण शोधासाठी इंटरनेट लागते.")
            }
            throw error
        }
    }
}
