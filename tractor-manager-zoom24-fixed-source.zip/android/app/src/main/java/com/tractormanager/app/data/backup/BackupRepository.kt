package com.tractormanager.app.data.backup

import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import com.tractormanager.app.data.local.AppDatabase
import com.tractormanager.app.data.local.WorkTypeSeed
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BackupRepository(
    private val context: Context,
    private val database: AppDatabase
) {

    suspend fun buildCurrentPayload(): BackupPayload = withContext(Dispatchers.IO) {
        BackupPayload(
            schemaVersion = BackupPayload.SCHEMA_VERSION,
            exportedAt = System.currentTimeMillis(),
            farmers = database.farmerDao().getAll(),
            fields = database.landFieldDao().getAll(),
            workRecords = database.workRecordDao().getAll(),
            payments = database.paymentDao().getAll(),
            workTypes = database.workTypeDao().getAll()
        )
    }

    suspend fun exportJson(): String = withContext(Dispatchers.IO) {
        BackupCodec.encode(buildCurrentPayload())
    }

    suspend fun exportToUri(uri: Uri): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val json = exportJson()
            val output = context.contentResolver.openOutputStream(uri)
                ?: throw IllegalStateException("फाईल लिहिण्यासाठी जागा उघडता आली नाही.")
            output.use { it.write(json.toByteArray(Charsets.UTF_8)) }
        }
    }

    suspend fun importFromUri(uri: Uri): Result<ImportSummary> = withContext(Dispatchers.IO) {
        runCatching {
            val raw = context.contentResolver.openInputStream(uri)?.use { stream ->
                stream.readBytes().toString(Charsets.UTF_8)
            } ?: throw IllegalStateException("बॅकअप फाईल वाचता आली नाही.")
            importFromJson(raw).getOrThrow()
        }
    }

    suspend fun importFromJson(raw: String): Result<ImportSummary> = withContext(Dispatchers.IO) {
        runCatching {
            val remote = BackupCodec.decode(raw).getOrThrow()
            val local = buildCurrentPayload()
            val merged = DataMerger.merge(local, remote)
            createSafetyBackup("restore")
            applySnapshot(merged)
            ImportSummary(
                farmers = merged.farmers.size,
                fields = merged.fields.size,
                workRecords = merged.workRecords.size,
                payments = merged.payments.size
            )
        }
    }

    suspend fun applySnapshot(payload: BackupPayload): Unit = withContext(Dispatchers.IO) {
        database.withTransaction {
            database.paymentDao().deleteAllHard()
            database.workRecordDao().deleteAllHard()
            database.landFieldDao().deleteAllHard()
            database.farmerDao().deleteAllHard()
            database.workTypeDao().deleteAllHard()

            if (payload.workTypes.isEmpty()) {
                database.workTypeDao().insertAll(WorkTypeSeed.defaults)
            } else {
                database.workTypeDao().insertAll(payload.workTypes)
            }
            if (payload.farmers.isNotEmpty()) database.farmerDao().upsertAll(payload.farmers)
            if (payload.fields.isNotEmpty()) database.landFieldDao().upsertAll(payload.fields)
            if (payload.workRecords.isNotEmpty()) database.workRecordDao().upsertAll(payload.workRecords)
            if (payload.payments.isNotEmpty()) database.paymentDao().upsertAll(payload.payments)
        }
    }

    suspend fun createSafetyBackup(label: String): File? = withContext(Dispatchers.IO) {
        runCatching {
            val dir = File(context.filesDir, "backups").apply { mkdirs() }
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val file = File(dir, "safety_${label}_$stamp.json")
            file.writeText(exportJson(), Charsets.UTF_8)
            dir.listFiles()
                ?.filter { it.name.startsWith("safety_") }
                ?.sortedByDescending { it.lastModified() }
                ?.drop(5)
                ?.forEach { it.delete() }
            file
        }.getOrNull()
    }
}
