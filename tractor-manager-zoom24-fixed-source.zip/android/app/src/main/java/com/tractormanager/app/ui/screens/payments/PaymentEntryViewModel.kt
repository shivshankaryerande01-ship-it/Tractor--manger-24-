package com.tractormanager.app.ui.screens.payments

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tractormanager.app.core.DateUtils
import com.tractormanager.app.core.DuplicateRecordException
import com.tractormanager.app.core.Money
import com.tractormanager.app.core.NumberText
import com.tractormanager.app.core.ValidationFailureException
import com.tractormanager.app.data.local.Farmer
import com.tractormanager.app.data.repository.FarmerRepository
import com.tractormanager.app.data.repository.PaymentRepository
import com.tractormanager.app.domain.PaymentCalculator
import com.tractormanager.app.domain.PaymentSummary
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PaymentEntryState(
    val farmers: List<Farmer> = emptyList(),
    val selectedFarmerId: String = "",
    val amountText: String = "",
    val dateEpochDay: Long = DateUtils.todayEpochDay(),
    val method: String = "रोख",
    val kind: String = "",
    val note: String = "",
    val summary: PaymentSummary = PaymentCalculator.summarize(0.0, 0.0),
    val saving: Boolean = false,
    val errors: Map<String, String> = emptyMap(),
    val message: String? = null,
    val saved: Boolean = false
)

@OptIn(ExperimentalCoroutinesApi::class)
class PaymentEntryViewModel(
    private val initialFarmerId: String?,
    private val farmerRepository: FarmerRepository,
    private val paymentRepository: PaymentRepository
) : ViewModel() {

    private val _state = MutableStateFlow(PaymentEntryState())
    val state: StateFlow<PaymentEntryState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            farmerRepository.observeFarmers().collect { farmers ->
                _state.update { current ->
                    val selected = current.selectedFarmerId.ifBlank {
                        initialFarmerId?.takeIf { id -> farmers.any { it.id == id } }
                            ?: farmers.firstOrNull()?.id.orEmpty()
                    }
                    current.copy(
                        farmers = farmers,
                        selectedFarmerId = if (farmers.any { it.id == selected }) selected else farmers.firstOrNull()?.id.orEmpty()
                    )
                }
            }
        }
        viewModelScope.launch {
            _state.map { it.selectedFarmerId }
                .distinctUntilChanged()
                .flatMapLatest { farmerId ->
                    if (farmerId.isBlank()) flowOf(PaymentCalculator.summarize(0.0, 0.0))
                    else paymentRepository.observeAccount(farmerId)
                }
                .collect { summary ->
                    _state.update { it.copy(summary = summary) }
                }
        }
    }

    fun onFarmerSelected(id: String) {
        _state.update {
            it.copy(
                selectedFarmerId = id,
                errors = it.errors - "farmer",
                kind = ""
            )
        }
    }

    fun onAmountChange(value: String) {
        val clean = value.filter { it.isDigit() || it == '.' }.take(12)
        _state.update { it.copy(amountText = clean, errors = it.errors - "amount") }
    }

    fun onDateSelected(epochDay: Long) = _state.update { it.copy(dateEpochDay = epochDay) }
    fun onMethodSelected(method: String) = _state.update { it.copy(method = method) }
    fun onKindSelected(kind: String) = _state.update { it.copy(kind = kind) }
    fun onNoteChange(value: String) = _state.update { it.copy(note = value) }

    fun fillFullBalance() {
        val amount = _state.value.summary.outstanding
        if (amount <= 0) {
            _state.update { it.copy(message = "या शेतकऱ्याचे काही बाकी नाही.") }
            return
        }
        _state.update {
            it.copy(
                amountText = NumberText.format(amount, 2),
                kind = "पूर्ण",
                errors = it.errors - "amount"
            )
        }
    }

    fun fillHalfBalance() {
        val amount = _state.value.summary.outstanding / 2.0
        if (amount <= 0) {
            _state.update { it.copy(message = "या शेतकऱ्याचे काही बाकी नाही.") }
            return
        }
        _state.update {
            it.copy(
                amountText = NumberText.format(amount, 2),
                kind = "आंशिक",
                errors = it.errors - "amount"
            )
        }
    }

    fun save() {
        if (_state.value.saving) return
        val current = _state.value
        val amount = current.amountText.toDoubleOrNull()
        if (amount == null) {
            _state.update {
                it.copy(
                    errors = it.errors + ("amount" to "वैध रक्कम टाका."),
                    message = "वैध रक्कम टाका."
                )
            }
            return
        }
        _state.update { it.copy(saving = true, message = null, errors = emptyMap()) }
        viewModelScope.launch {
            paymentRepository.savePayment(
                id = null,
                farmerId = current.selectedFarmerId,
                amount = amount,
                dateEpochDay = current.dateEpochDay,
                method = current.method,
                kind = current.kind.ifBlank { null },
                note = current.note
            ).fold(
                onSuccess = { _state.update { it.copy(saving = false, saved = true) } },
                onFailure = { error ->
                    when (error) {
                        is ValidationFailureException -> _state.update {
                            it.copy(
                                saving = false,
                                errors = error.result.errors,
                                message = error.result.errors.values.firstOrNull()
                            )
                        }
                        is DuplicateRecordException -> _state.update {
                            it.copy(saving = false, message = error.message)
                        }
                        else -> _state.update {
                            it.copy(saving = false, message = error.message ?: "पेमेंट जतन करता आले नाही.")
                        }
                    }
                }
            )
        }
    }

    fun clearMessage() = _state.update { it.copy(message = null) }
}
