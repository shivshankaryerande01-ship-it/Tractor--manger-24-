package com.tractormanager.app.util

import android.content.Context
import android.net.Uri
import com.tractormanager.app.core.DateUtils
import com.tractormanager.app.core.Money
import com.tractormanager.app.core.NumberText
import com.tractormanager.app.data.repository.MonthReport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object CsvExporter {

    fun buildMonthCsv(report: MonthReport): String {
        val builder = StringBuilder()
        builder.append('\uFEFF')
        builder.appendLine("काम अहवाल,${DateUtils.formatMonth(report.monthEpochDay)}")
        builder.appendLine()
        builder.appendLine("दिनांक,शेतकरी,मोबाईल,शेत,काम,एकर,दर (रु/एकर),एकूण (रु),नोंद")
        report.works.sortedWith(compareBy({ it.work.dateEpochDay }, { it.work.createdAt })).forEach { row ->
            builder.appendLine(
                listOf(
                    DateUtils.formatDate(row.work.dateEpochDay),
                    row.farmerName,
                    row.farmerMobile,
                    row.fieldName.orEmpty(),
                    row.work.workTypeName,
                    NumberText.format(row.work.acres, 3),
                    NumberText.format(row.work.ratePerAcre, 2),
                    NumberText.format(row.work.totalAmount, 2),
                    row.work.notes
                ).joinToString(",") { escape(it) }
            )
        }
        builder.appendLine(
            listOf("", "", "", "", "एकूण", NumberText.format(report.totalAcres, 3), "", NumberText.format(report.totalBilled, 2), "").joinToString(",") { escape(it) }
        )
        builder.appendLine()
        builder.appendLine("जमा अहवाल,${DateUtils.formatMonth(report.monthEpochDay)}")
        builder.appendLine("दिनांक,शेतकरी,मोबाईल,रक्कम (रु),पद्धत,प्रकार,नोंद")
        report.payments.sortedBy { it.payment.dateEpochDay }.forEach { row ->
            builder.appendLine(
                listOf(
                    DateUtils.formatDate(row.payment.dateEpochDay),
                    row.farmerName,
                    row.farmerMobile,
                    NumberText.format(row.payment.amount, 2),
                    row.payment.method,
                    row.payment.kind,
                    row.payment.note
                ).joinToString(",") { escape(it) }
            )
        }
        builder.appendLine(
            listOf("", "", "", NumberText.format(report.totalReceived, 2), "", "", "एकूण").joinToString(",") { escape(it) }
        )
        builder.appendLine()
        builder.appendLine("शेतकरीनिहाय बाकी")
        builder.appendLine("शेतकरी,मोबाईल,महिन्याचे बिल (रु),महिन्याची जमा (रु),एकूण बाकी (रु),स्थिती")
        report.farmers.forEach { farmer ->
            builder.appendLine(
                listOf(
                    farmer.name,
                    farmer.mobile,
                    NumberText.format(farmer.monthBilled, 2),
                    NumberText.format(farmer.monthReceived, 2),
                    NumberText.format(farmer.totalOutstanding, 2),
                    farmer.status.marathiLabel
                ).joinToString(",") { escape(it) }
            )
        }
        builder.appendLine()
        builder.appendLine("एकूण बाकी (सर्व शेतकरी),${Money.formatPlain(report.totalOutstanding)}")
        return builder.toString()
    }

    private fun escape(value: String): String {
        val clean = value.replace("\r", " ").replace("\n", " ")
        return if (clean.contains(',') || clean.contains('"')) {
            "\"${clean.replace("\"", "\"\"")}\""
        } else {
            clean
        }
    }

    suspend fun writeToUri(context: Context, uri: Uri, content: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val stream = context.contentResolver.openOutputStream(uri)
                    ?: throw IllegalStateException("CSV फाईल जतन करण्यासाठी जागा मिळाली नाही.")
                stream.use { it.write(content.toByteArray(Charsets.UTF_8)) }
            }
        }
}
