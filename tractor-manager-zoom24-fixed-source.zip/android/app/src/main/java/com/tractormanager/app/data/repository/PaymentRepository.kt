package com.tractormanager.app.data.repository

import com.tractormanager.app.core.DuplicateRecordException
import com.tractormanager.app.core.Ids
import com.tractormanager.app.core.ValidationFailureException
import com.tractormanager.app.core.Validators
import com.tractormanager.app.data.local.FarmerDao
import com.tractormanager.app.data.local.Payment
import com.tractormanager.app.data.local.PaymentDao
import com.tractormanager.app.data.local.PaymentRow
import com.tractormanager.app.data.local.WorkRecordDao
import com.tractormanager.app.domain.PaymentCalculator
import com.tractormanager.app.domain.PaymentSummary
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

class PaymentRepository(
    private val paymentDao: PaymentDao,
    private val workRecordDao: WorkRecordDao,
    private val farmerDao: FarmerDao
) {

    fun observeAll(): Flow<List<PaymentRow>> = paymentDao.observeAll()

    fun observeByFarmer(farmerId: String): Flow<List<PaymentRow>> =
        paymentDao.observeByFarmer(farmerId)

    fun observeReceivedTotal(): Flow<Double> = paymentDao.observeReceivedTotal()

    fun observeAccount(farmerId: String): Flow<PaymentSummary> = combine(
        workRecordDao.observeBilledForFarmer(farmerId),
        paymentDao.observeReceivedForFarmer(farmerId)
    ) { billed, received ->
        PaymentCalculator.summarize(billed, received)
    }

    suspend fun getForFarmer(farmerId: String): List<Payment> =
        paymentDao.getForFarmer(farmerId)

    fun observeReceivedBetween(startDay: Long, endDay: Long): Flow<Double> =
        paymentDao.observeReceivedBetween(startDay, endDay)

    suspend fun savePayment(
        id: String?,
        farmerId: String,
        amount: Double?,
        dateEpochDay: Long,
        method: String,
        kind: String?,
        note: String
    ): Result<String> {
        val validation = Validators.payment(farmerId, amount)
        if (!validation.isValid) return Result.failure(ValidationFailureException(validation))
        val validAmount = amount ?: return Result.failure(ValidationFailureException(validation))

        val farmer = farmerDao.getById(farmerId)
        if (farmer == null || farmer.isDeleted) {
            return Result.failure(IllegalStateException("शेतकरी सापडला नाही."))
        }
        if (dateEpochDay > com.tractormanager.app.core.DateUtils.todayEpochDay() + 1) {
            return Result.failure(IllegalStateException("भविष्यातील तारीख निवडू शकत नाही."))
        }

        val duplicate = paymentDao.countPotentialDuplicates(
            farmerId = farmerId,
            dateEpochDay = dateEpochDay,
            method = method,
            amount = validAmount,
            excludeId = id ?: ""
        )
        if (duplicate > 0) {
            return Result.failure(
                DuplicateRecordException("हीच रक्कम याच तारखेला आधीच जमा आहे. डबल नोंद टाळली.")
            )
        }

        val now = System.currentTimeMillis()
        val existing = if (id != null) paymentDao.getAll().firstOrNull { it.id == id } else null
        val billed = workRecordDao.getForFarmer(farmerId).sumOf { it.totalAmount }
        val alreadyReceived = paymentDao.getForFarmer(farmerId)
            .filter { it.id != id }
            .sumOf { it.amount }
        val resolvedKind = kind?.takeIf { it.isNotBlank() }
            ?: PaymentCalculator.paymentKindFor(billed, alreadyReceived, validAmount)

        return runCatching {
            if (id == null) {
                val newId = Ids.newId()
                paymentDao.insert(
                    Payment(
                        id = newId,
                        farmerId = farmerId,
                        amount = com.tractormanager.app.core.Money.round(validAmount),
                        dateEpochDay = dateEpochDay,
                        method = method,
                        kind = resolvedKind,
                        note = note.trim(),
                        createdAt = now,
                        updatedAt = now
                    )
                )
                newId
            } else {
                val record = existing ?: throw IllegalStateException("पेमेंट सापडले नाही.")
                paymentDao.update(
                    record.copy(
                        farmerId = farmerId,
                        amount = com.tractormanager.app.core.Money.round(validAmount),
                        dateEpochDay = dateEpochDay,
                        method = method,
                        kind = resolvedKind,
                        note = note.trim(),
                        updatedAt = now
                    )
                )
                id
            }
        }
    }

    suspend fun deletePayment(id: String): Result<Unit> = runCatching {
        paymentDao.softDelete(id, System.currentTimeMillis())
    }
}
