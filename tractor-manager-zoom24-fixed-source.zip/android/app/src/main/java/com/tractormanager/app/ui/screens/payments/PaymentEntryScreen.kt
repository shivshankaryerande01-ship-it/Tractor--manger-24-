package com.tractormanager.app.ui.screens.payments

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tractormanager.app.core.Money
import com.tractormanager.app.ui.appViewModel
import com.tractormanager.app.ui.components.AppCard
import com.tractormanager.app.ui.components.AppTextField
import com.tractormanager.app.ui.components.DateInput
import com.tractormanager.app.ui.components.DropdownOption
import com.tractormanager.app.ui.components.EmptyState
import com.tractormanager.app.ui.components.ErrorBanner
import com.tractormanager.app.ui.components.InfoBanner
import com.tractormanager.app.ui.components.LabeledDropdown
import com.tractormanager.app.ui.components.PrimaryButton
import com.tractormanager.app.ui.components.ScreenScaffold
import com.tractormanager.app.ui.components.StatusPill
import com.tractormanager.app.ui.components.ValueRow
import com.tractormanager.app.ui.theme.Danger
import com.tractormanager.app.ui.theme.Green50
import com.tractormanager.app.ui.theme.Green700
import com.tractormanager.app.ui.theme.Green900
import com.tractormanager.app.ui.theme.InkSoft

@Composable
fun PaymentEntryScreen(
    initialFarmerId: String?,
    onBack: () -> Unit,
    onSaved: () -> Unit,
    onAddFarmer: () -> Unit
) {
    val viewModel = appViewModel {
        PaymentEntryViewModel(initialFarmerId, it.farmerRepository, it.paymentRepository)
    }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(state.saved) {
        if (state.saved) onSaved()
    }
    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    val farmerOptions = state.farmers.map {
        DropdownOption(it.id, it.name, "${it.mobile}${if (it.village.isNotBlank()) " • ${it.village}" else ""}")
    }
    val methods = listOf("रोख", "UPI", "बँक", "चेक").map { DropdownOption(it, it) }
    val kinds = listOf(
        DropdownOption("", "आपोआप ठरवा"),
        DropdownOption("अ‍ॅडव्हान्स", "अ‍ॅडव्हान्स"),
        DropdownOption("आंशिक", "आंशिक पेमेंट"),
        DropdownOption("पूर्ण", "पूर्ण पेमेंट")
    )
    val selectedFarmer = state.farmers.firstOrNull { it.id == state.selectedFarmerId }

    ScreenScaffold(
        title = "पैसे नोंदवा",
        subtitle = "अ‍ॅडव्हान्स किंवा आंशिक पेमेंट",
        onBack = onBack,
        snackbarHostState = snackbar
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .imePadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (state.farmers.isEmpty()) {
                EmptyState(
                    title = "आधी शेतकरी जोडा",
                    message = "पेमेंट नोंदवण्यासाठी शेतकरी आवश्यक आहे.",
                    icon = Icons.Outlined.Groups,
                    actionLabel = "शेतकरी जोडा",
                    onAction = onAddFarmer
                )
                return@Column
            }

            AppCard(containerColor = Green50) {
                Column {
                    Row {
                        Column(Modifier.weight(1f)) {
                            Text("शेतकऱ्याची बाकी", style = MaterialTheme.typography.bodySmall, color = InkSoft)
                            Text(
                                Money.format(state.summary.outstanding),
                                style = MaterialTheme.typography.headlineMedium,
                                color = Danger
                            )
                        }
                        StatusPill(state.summary.status)
                    }
                    Spacer(Modifier.height(10.dp))
                    ValueRow("एकूण बिल", Money.format(state.summary.totalBilled))
                    ValueRow("आतापर्यंत जमा", Money.format(state.summary.totalReceived), Green700)
                    if (state.summary.advance > 0) {
                        ValueRow("जादा जमा", Money.format(state.summary.advance), Green700)
                    }
                }
            }

            AppCard {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    LabeledDropdown(
                        label = "शेतकरी *",
                        options = farmerOptions,
                        selectedId = state.selectedFarmerId,
                        onSelected = { viewModel.onFarmerSelected(it.id) },
                        error = state.errors["farmer"]
                    )
                    AppTextField(
                        value = state.amountText,
                        onValueChange = viewModel::onAmountChange,
                        label = "मिळालेली रक्कम (₹) *",
                        placeholder = "उदा. 5000",
                        keyboardType = KeyboardType.Decimal,
                        error = state.errors["amount"]
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = viewModel::fillFullBalance,
                            modifier = Modifier.weight(1f)
                        ) { Text("पूर्ण बाकी") }
                        OutlinedButton(
                            onClick = viewModel::fillHalfBalance,
                            modifier = Modifier.weight(1f)
                        ) { Text("अर्धी रक्कम") }
                    }
                    DateInput(
                        label = "पैसे मिळाल्याची तारीख",
                        epochDay = state.dateEpochDay,
                        onDateSelected = viewModel::onDateSelected
                    )
                    LabeledDropdown(
                        label = "पेमेंट पद्धत",
                        options = methods,
                        selectedId = state.method,
                        onSelected = { viewModel.onMethodSelected(it.id) }
                    )
                    LabeledDropdown(
                        label = "पेमेंट प्रकार",
                        options = kinds,
                        selectedId = state.kind,
                        onSelected = { viewModel.onKindSelected(it.id) },
                        placeholder = "आपोआप"
                    )
                    AppTextField(
                        value = state.note,
                        onValueChange = viewModel::onNoteChange,
                        label = "नोंद (ऐच्छिक)",
                        placeholder = "उदा. UPI संदर्भ क्रमांक",
                        singleLine = false,
                        maxLines = 2
                    )
                }
            }

            if (selectedFarmer != null) {
                InfoBanner(
                    "${selectedFarmer.name} यांच्याकडे एकूण ${Money.format(state.summary.totalBilled)} चे बिल आहे. " +
                        "जमा झालेली रक्कम आपोआप वजा होईल."
                )
            }
            ErrorBanner(state.message)

            PrimaryButton(
                text = "पेमेंट जतन करा",
                onClick = viewModel::save,
                loading = state.saving,
                enabled = state.selectedFarmerId.isNotBlank() && state.amountText.isNotBlank(),
                icon = Icons.Outlined.Save
            )
        }
    }
}
