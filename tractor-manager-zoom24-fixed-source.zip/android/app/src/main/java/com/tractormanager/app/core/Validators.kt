package com.tractormanager.app.core

import com.tractormanager.app.core.geo.GeoPoint

data class ValidationResult(val errors: Map<String, String>) {
    val isValid: Boolean get() = errors.isEmpty()

    fun error(key: String): String? = errors[key]
}

object Validators {

    private val mobileRegex = Regex("^[6-9][0-9]{9}$")

    fun farmer(name: String, mobile: String): ValidationResult {
        val errors = mutableMapOf<String, String>()
        val cleanName = name.trim()
        val cleanMobile = mobile.trim()
        when {
            cleanName.isEmpty() -> errors["name"] = "शेतकऱ्याचे नाव आवश्यक आहे."
            cleanName.length < 2 -> errors["name"] = "नाव किमान २ अक्षरांचे असावे."
            cleanName.length > 80 -> errors["name"] = "नाव ८० अक्षरांपेक्षा जास्त नसावे."
        }
        when {
            cleanMobile.isEmpty() -> errors["mobile"] = "मोबाईल नंबर आवश्यक आहे."
            !mobileRegex.matches(cleanMobile) ->
                errors["mobile"] = "१० अंकी मोबाईल नंबर द्या (६, ७, ८ किंवा ९ ने सुरू)."
        }
        return ValidationResult(errors)
    }

    fun landField(
        name: String,
        points: List<GeoPoint>,
        areaSqm: Double,
        village: String = ""
    ): ValidationResult {
        val errors = mutableMapOf<String, String>()
        when {
            name.trim().isEmpty() -> errors["name"] = "शेताचे नाव आवश्यक आहे."
            name.trim().length > 80 -> errors["name"] = "शेताचे नाव ८० अक्षरांपेक्षा जास्त नसावे."
        }
        if (points.size < 3) {
            errors["points"] = "नकाशावर किमान ३ सीमा बिंदू तयार करा."
        } else if (points.any { !it.isValid() }) {
            errors["points"] = "नकाशावरील बिंदू अयोग्य आहेत. पुन्हा मोजा."
        } else if (com.tractormanager.app.core.geo.GeoAreaCalculator.isSelfIntersecting(points)) {
            errors["points"] = "सीमारेषा स्वतःला छेदते. बिंदू योग्य क्रमाने पुन्हा लावा."
        }
        if (areaSqm <= 1.0) {
            errors["area"] = "क्षेत्रफळ खूप लहान आहे. सीमा पुन्हा मोजा."
        }
        if (village.trim().length > 80) {
            errors["village"] = "गावाचे नाव ८० अक्षरांपेक्षा जास्त नसावे."
        }
        return ValidationResult(errors)
    }

    fun workRecord(
        farmerId: String,
        fieldId: String,
        workType: String,
        acres: Double?,
        rate: Double?
    ): ValidationResult {
        val errors = mutableMapOf<String, String>()
        if (farmerId.isBlank()) errors["farmer"] = "शेतकरी निवडा."
        if (fieldId.isBlank()) errors["field"] = "जमीन निवडा."
        if (workType.isBlank()) errors["workType"] = "कामाचा प्रकार निवडा."
        if (acres == null || acres <= 0.0) {
            errors["acres"] = "एकर ० पेक्षा जास्त असावे."
        } else if (acres > 100_000) {
            errors["acres"] = "एकर असामान्य आहेत. पुन्हा तपासा."
        }
        if (rate == null || rate < 0.0) {
            errors["rate"] = "दर ० किंवा त्यापेक्षा जास्त असावा."
        } else if (rate > 1_000_000) {
            errors["rate"] = "दर असामान्य आहे. पुन्हा तपासा."
        }
        return ValidationResult(errors)
    }

    fun payment(farmerId: String, amount: Double?): ValidationResult {
        val errors = mutableMapOf<String, String>()
        if (farmerId.isBlank()) errors["farmer"] = "शेतकरी निवडा."
        if (amount == null || amount <= 0.0) {
            errors["amount"] = "रक्कम ० पेक्षा जास्त असावी."
        } else if (amount > 10_00_00_000) {
            errors["amount"] = "रक्कम असामान्य आहे. पुन्हा तपासा."
        }
        return ValidationResult(errors)
    }

    fun pin(pin: String, confirmPin: String? = null): ValidationResult {
        val errors = mutableMapOf<String, String>()
        if (!pin.matches(Regex("^[0-9]{4,6}$"))) {
            errors["pin"] = "PIN ४ ते ६ अंकांचा असावा."
        }
        if (confirmPin != null && pin != confirmPin) {
            errors["confirmPin"] = "दोन्ही PIN जुळत नाहीत."
        }
        return ValidationResult(errors)
    }

    fun syncSettings(url: String, code: String): ValidationResult {
        val errors = mutableMapOf<String, String>()
        if (url.isNotBlank() && !url.startsWith("https://")) {
            errors["url"] = "Firebase URL https:// ने सुरू होणे आवश्यक आहे."
        }
        if (url.isNotBlank() && code.isBlank()) {
            errors["code"] = "सिंक कोड आवश्यक आहे (उदा. घर किंवा ट्रॅक्टरचे नाव)."
        }
        return ValidationResult(errors)
    }
}
