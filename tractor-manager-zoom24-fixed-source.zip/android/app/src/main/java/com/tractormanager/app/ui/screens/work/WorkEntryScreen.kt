package com.tractormanager.app.ui.screens.work

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Agriculture
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tractormanager.app.core.Money
import com.tractormanager.app.core.NumberText
import com.tractormanager.app.ui.appViewModel
import com.tractormanager.app.ui.components.AppCard
import com.tractormanager.app.ui.components.AppTextField
import com.tractormanager.app.ui.components.DateInput
import com.tractormanager.app.ui.components.DropdownOption
import com.tractormanager.app.ui.components.EmptyState
import com.tractormanager.app.ui.components.ErrorBanner
import com.tractormanager.app.ui.components.InfoBanner
import com.tractormanager.app.ui.components.LabeledDropdown
import com.tractormanager.app.ui.components.PrimaryButton
import com.tractormanager.app.ui.components.ScreenScaffold
import com.tractormanager.app.ui.theme.Green50
import com.tractormanager.app.ui.theme.Green700
import com.tractormanager.app.ui.theme.Green900
import com.tractormanager.app.ui.theme.Ink
import com.tractormanager.app.ui.theme.InkSoft

@Composable
fun WorkEntryScreen(
    initialFarmerId: String?,
    initialFieldId: String?,
    onBack: () -> Unit,
    onSaved: () -> Unit,
    onAddFarmer: () -> Unit,
    onAddField: (String) -> Unit
) {
    val viewModel = appViewModel {
        WorkEntryViewModel(
            initialFarmerId = initialFarmerId,
            initialFieldId = initialFieldId,
            farmerRepository = it.farmerRepository,
            fieldRepository = it.fieldRepository,
            workTypeRepository = it.workTypeRepository,
            workRepository = it.workRepository
        )
    }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(state.saved) {
        if (state.saved) onSaved()
    }
    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    val farmerOptions = state.farmers.map {
        DropdownOption(it.id, it.name, "${it.mobile}${if (it.village.isNotBlank()) " • ${it.village}" else ""}")
    }
    val fieldOptions = state.fields.map {
        DropdownOption(
            it.id,
            it.name,
            "${NumberText.format(it.areaAcres, 3)} एकर • ${NumberText.format(it.areaGuntha, 1)} गुंठे"
        )
    }
    val typeOptions = state.workTypes.map {
        DropdownOption(it.id, it.name, "मूळ दर ${Money.format(it.defaultRate)} / एकर")
    }

    ScreenScaffold(
        title = "कामाची नोंद",
        subtitle = "एकर × दर = एकूण रक्कम",
        onBack = onBack,
        snackbarHostState = snackbar
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .imePadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (state.farmers.isEmpty()) {
                EmptyState(
                    title = "आधी शेतकरी जोडा",
                    message = "कामाची नोंद करण्यासाठी शेतकरी आणि त्याची जमीन आवश्यक आहे.",
                    icon = Icons.Outlined.Groups,
                    actionLabel = "शेतकरी जोडा",
                    onAction = onAddFarmer
                )
                return@Column
            }

            AppCard {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    LabeledDropdown(
                        label = "शेतकरी *",
                        options = farmerOptions,
                        selectedId = state.selectedFarmerId,
                        onSelected = { viewModel.onFarmerSelected(it.id) },
                        error = state.errors["farmer"]
                    )
                    LabeledDropdown(
                        label = "जमीन *",
                        options = fieldOptions,
                        selectedId = state.selectedFieldId,
                        onSelected = { viewModel.onFieldSelected(it.id) },
                        error = state.errors["field"],
                        enabled = state.fields.isNotEmpty()
                    )
                    if (state.fieldsLoading) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = Green700
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "जमिनी लोड होत आहेत...",
                                style = MaterialTheme.typography.bodySmall,
                                color = InkSoft
                            )
                        }
                    } else if (state.fields.isEmpty()) {
                        InfoBanner("या शेतकऱ्याची जमीन नोंदवलेली नाही. आधी जमीन मोजा.")
                        PrimaryButton(
                            text = "जमीन मोजा",
                            onClick = { onAddField(state.selectedFarmerId) },
                            icon = Icons.Outlined.Map,
                            modifier = Modifier.height(52.dp)
                        )
                    }
                    LabeledDropdown(
                        label = "कामाचा प्रकार *",
                        options = typeOptions,
                        selectedId = state.selectedWorkTypeId,
                        onSelected = { viewModel.onWorkTypeSelected(it.id) },
                        error = state.errors["workType"]
                    )
                    DateInput(
                        label = "कामाची तारीख",
                        epochDay = state.dateEpochDay,
                        onDateSelected = viewModel::onDateSelected,
                        error = state.errors["date"]
                    )
                }
            }

            AppCard {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("क्षेत्रफळ आणि दर", style = MaterialTheme.typography.titleMedium, color = Ink)
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        AppTextField(
                            value = state.acresText,
                            onValueChange = viewModel::onAcresChange,
                            label = "क्षेत्रफळ (एकर) *",
                            placeholder = "उदा. 2.5",
                            keyboardType = KeyboardType.Decimal,
                            error = state.errors["acres"]
                        )
                        AppTextField(
                            value = state.rateText,
                            onValueChange = viewModel::onRateChange,
                            label = "दर (₹ / एकर) *",
                            placeholder = "उदा. 1200",
                            keyboardType = KeyboardType.Decimal,
                            error = state.errors["rate"]
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Agriculture, contentDescription = null, tint = Green700)
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "जमीन निवडल्यावर एकर आपोआप भरले जातात. प्रत्येक कामाच्या प्रकारासाठी वेगळा दर आहे; बदललेला दर याच नोंदीत प्रकार बदलल्यावरही टिकतो.",
                            style = MaterialTheme.typography.bodySmall,
                            color = InkSoft
                        )
                    }
                }
            }

            AppCard(containerColor = Green50) {
                Column {
                    Text("एकूण रक्कम", style = MaterialTheme.typography.bodySmall, color = InkSoft)
                    Text(
                        Money.format(state.total),
                        style = MaterialTheme.typography.headlineMedium,
                        color = Green900
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "${state.acresText.ifBlank { "0" }} एकर × ${Money.format(state.rateText.toDoubleOrNull() ?: 0.0)} = ${Money.format(state.total)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = InkSoft
                    )
                }
            }

            ErrorBanner(state.message)

            AppTextField(
                value = state.notes,
                onValueChange = viewModel::onNotesChange,
                label = "नोंद (ऐच्छिक)",
                placeholder = "उदा. दोन फेऱ्या, मालकाच्या वतीने...",
                singleLine = false,
                maxLines = 3
            )

            PrimaryButton(
                text = "काम जतन करा",
                onClick = viewModel::save,
                loading = state.saving,
                enabled = state.selectedFarmerId.isNotBlank() &&
                    state.selectedFieldId.isNotBlank() &&
                    state.selectedWorkTypeId.isNotBlank(),
                icon = Icons.Outlined.Save
            )

            Text(
                "रक्कम नोंदवल्यावर शेतकऱ्याच्या खात्यात बिल म्हणून जोडली जाईल. पैसे मिळाल्यावर स्वतंत्र पेमेंट नोंदवा.",
                style = MaterialTheme.typography.bodySmall,
                color = InkSoft
            )
        }
    }
}
