package com.tractormanager.app.ui.screens.farmers

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Agriculture
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tractormanager.app.core.Money
import com.tractormanager.app.data.repository.BillData
import com.tractormanager.app.data.local.PaymentRow
import com.tractormanager.app.ui.appViewModel
import com.tractormanager.app.ui.components.AppCard
import com.tractormanager.app.ui.components.ConfirmDialog
import com.tractormanager.app.ui.components.EmptyState
import com.tractormanager.app.ui.components.FieldListCard
import com.tractormanager.app.ui.components.LoadingScreen
import com.tractormanager.app.ui.components.PaymentListCard
import com.tractormanager.app.ui.components.ScreenScaffold
import com.tractormanager.app.ui.components.SectionHeader
import com.tractormanager.app.ui.components.StatusPill
import com.tractormanager.app.ui.components.WorkListCard
import com.tractormanager.app.ui.theme.Danger
import com.tractormanager.app.ui.theme.Green100
import com.tractormanager.app.ui.theme.Green50
import com.tractormanager.app.ui.theme.Green600
import com.tractormanager.app.ui.theme.Green700
import com.tractormanager.app.ui.theme.Green900
import com.tractormanager.app.ui.theme.Ink
import com.tractormanager.app.ui.theme.InkSoft
import com.tractormanager.app.ui.theme.White
import com.tractormanager.app.util.PdfGenerator
import com.tractormanager.app.util.ShareUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun FarmerDetailScreen(
    farmerId: String,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onAddField: () -> Unit,
    onEditField: (String) -> Unit,
    onAddWork: (String?) -> Unit,
    onAddPayment: () -> Unit
) {
    val viewModel = appViewModel {
        FarmerDetailViewModel(
            farmerId = farmerId,
            farmerRepository = it.farmerRepository,
            fieldRepository = it.fieldRepository,
            workRepository = it.workRepository,
            paymentRepository = it.paymentRepository,
            reportRepository = it.reportRepository
        )
    }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val deleted by viewModel.deleted.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val pdfGenerator = remember(context) { PdfGenerator(context) }
    var confirmDelete by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(deleted) {
        if (deleted) onBack()
    }
    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    fun billText(bill: BillData): String = buildString {
        append("नमस्कार ${bill.farmer.name}, ")
        append("आपल्या ट्रॅक्टर कामाचे बिल जोडले आहे. ")
        append("एकूण बिल ${Money.format(bill.summary.totalBilled)}, ")
        append("जमा ${Money.format(bill.summary.totalReceived)}, ")
        append("बाकी ${Money.format(bill.summary.outstanding)}. ")
        append("— ट्रॅक्टर मॅनेजर")
    }

    fun shareBill(whatsApp: Boolean) {
        if (busy) return
        scope.launch {
            busy = true
            try {
                val bill = viewModel.buildBill()
                if (bill == null) {
                    snackbar.showSnackbar("शेतकरी माहिती सापडली नाही.")
                    return@launch
                }
                if (bill.works.isEmpty()) {
                    snackbar.showSnackbar("बिल तयार करण्यासाठी आधी काम नोंदवा.")
                    return@launch
                }
                val file = withContext(Dispatchers.IO) { pdfGenerator.generateBill(bill) }
                ShareUtils.sharePdf(context, file, whatsApp, billText(bill))
            } catch (error: Exception) {
                snackbar.showSnackbar(error.message ?: "PDF तयार करता आले नाही.")
            } finally {
                busy = false
            }
        }
    }

    fun shareReceipt(row: PaymentRow) {
        if (busy) return
        scope.launch {
            busy = true
            try {
                val bill = viewModel.buildBill()
                if (bill == null) {
                    snackbar.showSnackbar("पावती तयार करता आली नाही.")
                    return@launch
                }
                val file = withContext(Dispatchers.IO) {
                    pdfGenerator.generateReceipt(bill, row.payment)
                }
                ShareUtils.sharePdf(
                    context,
                    file,
                    false,
                    "नमस्कार ${bill.farmer.name}, ${Money.format(row.payment.amount)} ची पावती जोडली आहे. — ट्रॅक्टर मॅनेजर"
                )
            } catch (error: Exception) {
                snackbar.showSnackbar(error.message ?: "पावती तयार करता आली नाही.")
            } finally {
                busy = false
            }
        }
    }

    val farmer = state.farmer
    if (state.loading) {
        LoadingScreen("शेतकऱ्याची माहिती लोड होत आहे...")
        return
    }
    if (farmer == null) {
        ScreenScaffold(title = "शेतकरी", onBack = onBack) { padding ->
            EmptyState(
                title = "शेतकरी सापडला नाही",
                message = "हा शेतकरी हटवलेला असू शकतो.",
                icon = Icons.Outlined.Agriculture,
                modifier = Modifier.padding(padding)
            )
        }
        return
    }

    ScreenScaffold(
        title = farmer.name,
        subtitle = farmer.mobile,
        onBack = onBack,
        snackbarHostState = snackbar,
        actions = {
            IconButton(onClick = onEdit) {
                Icon(Icons.Outlined.Edit, contentDescription = "संपादित करा")
            }
            IconButton(onClick = { confirmDelete = true }) {
                Icon(Icons.Outlined.Delete, contentDescription = "हटवा", tint = Danger)
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(listOf(Green700, Green600)),
                            RoundedCornerShape(24.dp)
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier
                                    .size(52.dp)
                                    .background(Color.White.copy(alpha = 0.2f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    farmer.name.trim().take(1).uppercase(),
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = Color.White
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    farmer.name,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    buildString {
                                        append(farmer.mobile)
                                        if (farmer.village.isNotBlank()) append(" • ${farmer.village}")
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.9f)
                                )
                            }
                            HeaderAction(Icons.Outlined.Call, "फोन") {
                                ShareUtils.dialPhone(context, farmer.mobile)
                            }
                            Spacer(Modifier.width(8.dp))
                            HeaderAction(Icons.Outlined.Chat, "व्हॉट्सॲप") {
                                ShareUtils.openWhatsAppChat(
                                    context,
                                    farmer.mobile,
                                    "नमस्कार ${farmer.name}, ट्रॅक्टर मॅनेजरकडून संपर्क."
                                )
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            HeaderMetric("एकूण बिल", Money.format(state.summary?.totalBilled ?: 0.0), Modifier.weight(1f))
                            HeaderMetric("जमा", Money.format(state.summary?.totalReceived ?: 0.0), Modifier.weight(1f))
                            HeaderMetric("बाकी", Money.format(state.summary?.outstanding ?: 0.0), Modifier.weight(1f))
                        }
                    }
                }
            }

            item {
                AppCard {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("पैशांची स्थिती", style = MaterialTheme.typography.bodySmall, color = InkSoft)
                                Text(
                                    Money.format(state.summary?.outstanding ?: 0.0),
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = if ((state.summary?.outstanding ?: 0.0) > 0) Danger else Green700
                                )
                            }
                            state.summary?.let { StatusPill(it.status) }
                        }
                        Spacer(Modifier.height(10.dp))
                        val billed = state.summary?.totalBilled ?: 0.0
                        val received = state.summary?.totalReceived ?: 0.0
                        val ratio = if (billed <= 0) 0f else (received / billed).toFloat().coerceIn(0f, 1f)
                        LinearProgressIndicator(
                            progress = { ratio },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp),
                            color = Green700,
                            trackColor = Green100
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            if ((state.summary?.advance ?: 0.0) > 0) {
                                "जादा जमा: ${Money.format(state.summary?.advance ?: 0.0)}"
                            } else {
                                "जमा ${Money.format(received)} / बिल ${Money.format(billed)}"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = InkSoft
                        )
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionTile("जमीन जोडा", Icons.Outlined.Map, onAddField, Modifier.weight(1f))
                    ActionTile("काम नोंदवा", Icons.Outlined.Agriculture, { onAddWork(state.fields.firstOrNull()?.id) }, Modifier.weight(1f))
                    ActionTile("पैसे घ्या", Icons.Outlined.Payments, onAddPayment, Modifier.weight(1f))
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ShareTile(
                        label = "बिल PDF",
                        icon = Icons.Outlined.Description,
                        onClick = { shareBill(false) },
                        modifier = Modifier.weight(1f)
                    )
                    ShareTile(
                        label = "WhatsApp बिल",
                        icon = Icons.Outlined.Share,
                        onClick = { shareBill(true) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                SectionHeader(
                    title = "जमिनी (${state.fields.size})",
                    actionLabel = "जोडा",
                    onAction = onAddField
                )
            }
            if (state.fields.isEmpty()) {
                item {
                    EmptyState(
                        title = "जमीन नोंदवलेली नाही",
                        message = "उपग्रह नकाशावर शेताची सीमा मोजून जमीन जोडा.",
                        icon = Icons.Outlined.Map,
                        actionLabel = "जमीन मोजा",
                        onAction = onAddField
                    )
                }
            } else {
                items(state.fields, key = { it.id }) { field ->
                    FieldListCard(field = field, onClick = { onEditField(field.id) })
                }
            }

            item {
                SectionHeader(
                    title = "कामाचा इतिहास (${state.works.size})",
                    actionLabel = "नोंदवा",
                    onAction = { onAddWork(state.fields.firstOrNull()?.id) }
                )
            }
            if (state.works.isEmpty()) {
                item {
                    EmptyState(
                        title = "कामाची नोंद नाही",
                        message = "या शेतकऱ्याचे ट्रॅक्टर काम नोंदवा.",
                        icon = Icons.Outlined.Agriculture,
                        actionLabel = "काम नोंदवा",
                        onAction = { onAddWork(state.fields.firstOrNull()?.id) }
                    )
                }
            } else {
                items(state.works, key = { it.work.id }) { row ->
                    WorkListCard(row = row, showFarmer = false)
                }
            }

            item {
                SectionHeader(
                    title = "पैशांचा इतिहास (${state.payments.size})",
                    actionLabel = "पैसे घ्या",
                    onAction = onAddPayment
                )
            }
            if (state.payments.isEmpty()) {
                item {
                    EmptyState(
                        title = "अजून पैसे मिळाले नाहीत",
                        message = "अ‍ॅडव्हान्स किंवा आंशिक पेमेंट नोंदवा.",
                        icon = Icons.Outlined.Payments,
                        actionLabel = "पैसे नोंदवा",
                        onAction = onAddPayment
                    )
                }
            } else {
                items(state.payments, key = { it.payment.id }) { row ->
                    PaymentListCard(
                        row = row,
                        showFarmer = false,
                        trailing = {
                            IconButton(onClick = { shareReceipt(row) }) {
                                Icon(
                                    Icons.Outlined.ReceiptLong,
                                    contentDescription = "पावती",
                                    tint = Green700
                                )
                            }
                        }
                    )
                }
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }

    if (confirmDelete) {
        ConfirmDialog(
            title = "शेतकरी हटवायचा?",
            message = "${farmer.name} यांची नोंद हटवली जाईल. जुना हिशोब बॅकअपमध्ये राहील. हे पुन्हा उघडता येणार नाही.",
            confirmLabel = "हटवा",
            destructive = true,
            onConfirm = {
                confirmDelete = false
                viewModel.deleteFarmer()
            },
            onDismiss = { confirmDelete = false }
        )
    }
}

@Composable
private fun HeaderAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = Color.White.copy(alpha = 0.18f),
        modifier = Modifier.size(38.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = description, tint = Color.White, modifier = Modifier.size(19.dp))
        }
    }
}

@Composable
private fun HeaderMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = Color.White.copy(alpha = 0.14f),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.85f))
            Text(
                value,
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ActionTile(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        onClick = onClick,
        color = Green50,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Green100)
    ) {
        Column(
            Modifier.padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = Green700, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(5.dp))
            Text(
                label,
                style = MaterialTheme.typography.labelMedium,
                color = Green900,
                maxLines = 2
            )
        }
    }
}

@Composable
private fun ShareTile(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        onClick = onClick,
        color = White,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Green100)
    ) {
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = Green700, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(label, style = MaterialTheme.typography.labelMedium, color = Green900)
        }
    }
}
