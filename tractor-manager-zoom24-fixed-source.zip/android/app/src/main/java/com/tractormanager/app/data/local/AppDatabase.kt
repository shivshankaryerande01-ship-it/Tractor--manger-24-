package com.tractormanager.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        Farmer::class,
        LandField::class,
        WorkRecord::class,
        Payment::class,
        WorkTypeRate::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun farmerDao(): FarmerDao
    abstract fun landFieldDao(): LandFieldDao
    abstract fun workRecordDao(): WorkRecordDao
    abstract fun paymentDao(): PaymentDao
    abstract fun workTypeDao(): WorkTypeDao

    companion object {
        private const val DB_NAME = "tractor_manager.db"

        fun create(context: Context): AppDatabase {
            return Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, DB_NAME)
                .addCallback(object : Callback() {
                    override fun onOpen(db: SupportSQLiteDatabase) {
                        super.onOpen(db)
                        seedWorkTypes(db)
                    }
                })
                .build()
        }

        /**
         * Adds the built-in work types and keeps their order stable without touching
         * rates or records that the user has already saved. Runs synchronously so
         * the first Room query already sees the seeded rows.
         */
        private fun seedWorkTypes(db: SupportSQLiteDatabase) {
            WorkTypeSeed.defaults.forEach { type ->
                db.execSQL(
                    "INSERT OR IGNORE INTO work_types (id, name, defaultRate, sortOrder, isDeleted) " +
                        "VALUES (?, ?, ?, ?, 0)",
                    arrayOf(type.id, type.name, type.defaultRate, type.sortOrder)
                )
                db.execSQL(
                    "UPDATE work_types SET sortOrder = ? WHERE id = ?",
                    arrayOf(type.sortOrder, type.id)
                )
            }
        }
    }
}
