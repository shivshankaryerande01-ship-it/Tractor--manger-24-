package com.tractormanager.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface FarmerDao {

    @Query("SELECT * FROM farmers WHERE isDeleted = 0 ORDER BY name COLLATE NOCASE")
    fun observeActive(): Flow<List<Farmer>>

    @Query(
        """
        SELECT f.*,
            COALESCE(w.billed, 0) AS billed,
            COALESCE(p.received, 0) AS received
        FROM farmers f
        LEFT JOIN (
            SELECT farmerId, SUM(totalAmount) AS billed
            FROM work_records WHERE isDeleted = 0 GROUP BY farmerId
        ) w ON w.farmerId = f.id
        LEFT JOIN (
            SELECT farmerId, SUM(amount) AS received
            FROM payments WHERE isDeleted = 0 GROUP BY farmerId
        ) p ON p.farmerId = f.id
        WHERE f.isDeleted = 0
        ORDER BY f.name COLLATE NOCASE
        """
    )
    fun observeWithBalances(): Flow<List<FarmerBalanceRow>>

    @Query("SELECT * FROM farmers WHERE id = :id AND isDeleted = 0")
    fun observeById(id: String): Flow<Farmer?>

    @Query("SELECT * FROM farmers WHERE id = :id")
    suspend fun getById(id: String): Farmer?

    @Query("SELECT * FROM farmers WHERE mobile = :mobile LIMIT 1")
    suspend fun findByMobile(mobile: String): Farmer?

    @Query("SELECT * FROM farmers WHERE isDeleted = 0 ORDER BY name COLLATE NOCASE")
    suspend fun getActive(): List<Farmer>

    @Query("SELECT * FROM farmers")
    suspend fun getAll(): List<Farmer>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(farmer: Farmer)

    @Update
    suspend fun update(farmer: Farmer)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(farmers: List<Farmer>)

    @Query("UPDATE farmers SET isDeleted = 1, updatedAt = :timestamp WHERE id = :id")
    suspend fun softDelete(id: String, timestamp: Long)

    @Query("SELECT COUNT(*) FROM farmers WHERE isDeleted = 0")
    suspend fun countActive(): Int

    @Query("SELECT COUNT(*) FROM farmers WHERE isDeleted = 0")
    fun observeCountActive(): Flow<Int>

    @Query("DELETE FROM farmers")
    suspend fun deleteAllHard()
}

@Dao
interface LandFieldDao {

    @Query("SELECT * FROM land_fields WHERE farmerId = :farmerId AND isDeleted = 0 ORDER BY createdAt DESC")
    fun observeByFarmer(farmerId: String): Flow<List<LandField>>

    @Query("SELECT * FROM land_fields WHERE isDeleted = 0 ORDER BY name COLLATE NOCASE")
    fun observeAllActive(): Flow<List<LandField>>

    @Query("SELECT * FROM land_fields WHERE id = :id")
    fun observeById(id: String): Flow<LandField?>

    @Query("SELECT * FROM land_fields WHERE id = :id")
    suspend fun getById(id: String): LandField?

    @Query("SELECT * FROM land_fields WHERE farmerId = :farmerId AND isDeleted = 0 ORDER BY name COLLATE NOCASE")
    suspend fun getActiveByFarmer(farmerId: String): List<LandField>

    @Query("SELECT * FROM land_fields")
    suspend fun getAll(): List<LandField>

    @Query("SELECT COUNT(*) FROM land_fields WHERE farmerId = :farmerId AND isDeleted = 0")
    suspend fun countByFarmer(farmerId: String): Int

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(field: LandField)

    @Update
    suspend fun update(field: LandField)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(fields: List<LandField>)

    @Query("UPDATE land_fields SET isDeleted = 1, updatedAt = :timestamp WHERE id = :id")
    suspend fun softDelete(id: String, timestamp: Long)

    @Query("DELETE FROM land_fields")
    suspend fun deleteAllHard()
}

@Dao
interface WorkRecordDao {

    @Query(
        """
        SELECT w.*, f.name AS farmerName, f.mobile AS farmerMobile, lf.name AS fieldName
        FROM work_records w
        INNER JOIN farmers f ON f.id = w.farmerId
        LEFT JOIN land_fields lf ON lf.id = w.fieldId
        WHERE w.isDeleted = 0
        ORDER BY w.dateEpochDay DESC, w.createdAt DESC
        """
    )
    fun observeAll(): Flow<List<WorkRecordRow>>

    @Query(
        """
        SELECT w.*, f.name AS farmerName, f.mobile AS farmerMobile, lf.name AS fieldName
        FROM work_records w
        INNER JOIN farmers f ON f.id = w.farmerId
        LEFT JOIN land_fields lf ON lf.id = w.fieldId
        WHERE w.isDeleted = 0 AND w.dateEpochDay BETWEEN :startDay AND :endDay
        ORDER BY w.dateEpochDay DESC, w.createdAt DESC
        """
    )
    fun observeBetween(startDay: Long, endDay: Long): Flow<List<WorkRecordRow>>

    @Query(
        """
        SELECT w.*, f.name AS farmerName, f.mobile AS farmerMobile, lf.name AS fieldName
        FROM work_records w
        INNER JOIN farmers f ON f.id = w.farmerId
        LEFT JOIN land_fields lf ON lf.id = w.fieldId
        WHERE w.isDeleted = 0 AND w.farmerId = :farmerId
        ORDER BY w.dateEpochDay DESC, w.createdAt DESC
        """
    )
    fun observeByFarmer(farmerId: String): Flow<List<WorkRecordRow>>

    @Query(
        """
        SELECT w.*, f.name AS farmerName, f.mobile AS farmerMobile, lf.name AS fieldName
        FROM work_records w
        INNER JOIN farmers f ON f.id = w.farmerId
        LEFT JOIN land_fields lf ON lf.id = w.fieldId
        WHERE w.isDeleted = 0
        ORDER BY w.dateEpochDay DESC, w.createdAt DESC
        LIMIT :limit
        """
    )
    fun observeRecent(limit: Int): Flow<List<WorkRecordRow>>

    @Query(
        """
        SELECT COUNT(*) AS workCount,
            COALESCE(SUM(acres), 0) AS acres,
            COALESCE(SUM(totalAmount), 0) AS amount
        FROM work_records
        WHERE isDeleted = 0 AND dateEpochDay BETWEEN :startDay AND :endDay
        """
    )
    fun observeTotals(startDay: Long, endDay: Long): Flow<WorkTotals>

    @Query("SELECT COALESCE(SUM(totalAmount), 0) FROM work_records WHERE isDeleted = 0 AND farmerId = :farmerId")
    fun observeBilledForFarmer(farmerId: String): Flow<Double>

    @Query("SELECT COALESCE(SUM(totalAmount), 0) FROM work_records WHERE isDeleted = 0")
    fun observeBilledTotal(): Flow<Double>

    @Query("SELECT COALESCE(SUM(acres), 0) FROM work_records WHERE isDeleted = 0 AND dateEpochDay = :day")
    fun observeAcresForDay(day: Long): Flow<Double>

    @Query("SELECT * FROM work_records WHERE isDeleted = 0 AND farmerId = :farmerId ORDER BY dateEpochDay DESC")
    suspend fun getForFarmer(farmerId: String): List<WorkRecord>

    @Query("SELECT * FROM work_records WHERE isDeleted = 0 AND dateEpochDay BETWEEN :startDay AND :endDay ORDER BY dateEpochDay ASC")
    suspend fun getBetween(startDay: Long, endDay: Long): List<WorkRecord>

    @Query("SELECT * FROM work_records")
    suspend fun getAll(): List<WorkRecord>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(record: WorkRecord)

    @Update
    suspend fun update(record: WorkRecord)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(records: List<WorkRecord>)

    @Query("UPDATE work_records SET isDeleted = 1, updatedAt = :timestamp WHERE id = :id")
    suspend fun softDelete(id: String, timestamp: Long)

    @Query("SELECT COUNT(*) FROM work_records WHERE isDeleted = 0")
    suspend fun countActive(): Int

    @Query(
        """
        SELECT COUNT(*) FROM work_records
        WHERE isDeleted = 0 AND id != :excludeId AND farmerId = :farmerId
            AND fieldId = :fieldId AND dateEpochDay = :dateEpochDay
            AND workTypeId = :workTypeId
            AND ABS(acres - :acres) < 0.00001
            AND ABS(ratePerAcre - :ratePerAcre) < 0.01
        """
    )
    suspend fun countExactDuplicates(
        farmerId: String,
        fieldId: String,
        dateEpochDay: Long,
        workTypeId: String,
        acres: Double,
        ratePerAcre: Double,
        excludeId: String
    ): Int

    @Query("DELETE FROM work_records")
    suspend fun deleteAllHard()
}

@Dao
interface PaymentDao {

    @Query(
        """
        SELECT p.*, f.name AS farmerName, f.mobile AS farmerMobile
        FROM payments p
        INNER JOIN farmers f ON f.id = p.farmerId
        WHERE p.isDeleted = 0
        ORDER BY p.dateEpochDay DESC, p.createdAt DESC
        """
    )
    fun observeAll(): Flow<List<PaymentRow>>

    @Query(
        """
        SELECT p.*, f.name AS farmerName, f.mobile AS farmerMobile
        FROM payments p
        INNER JOIN farmers f ON f.id = p.farmerId
        WHERE p.isDeleted = 0 AND p.farmerId = :farmerId
        ORDER BY p.dateEpochDay DESC, p.createdAt DESC
        """
    )
    fun observeByFarmer(farmerId: String): Flow<List<PaymentRow>>

    @Query(
        """
        SELECT p.*, f.name AS farmerName, f.mobile AS farmerMobile
        FROM payments p
        INNER JOIN farmers f ON f.id = p.farmerId
        WHERE p.isDeleted = 0 AND p.dateEpochDay BETWEEN :startDay AND :endDay
        ORDER BY p.dateEpochDay DESC, p.createdAt DESC
        """
    )
    fun observeBetween(startDay: Long, endDay: Long): Flow<List<PaymentRow>>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE isDeleted = 0 AND farmerId = :farmerId")
    fun observeReceivedForFarmer(farmerId: String): Flow<Double>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE isDeleted = 0")
    fun observeReceivedTotal(): Flow<Double>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE isDeleted = 0 AND dateEpochDay BETWEEN :startDay AND :endDay")
    fun observeReceivedBetween(startDay: Long, endDay: Long): Flow<Double>

    @Query("SELECT * FROM payments WHERE isDeleted = 0 AND farmerId = :farmerId ORDER BY dateEpochDay DESC")
    suspend fun getForFarmer(farmerId: String): List<Payment>

    @Query("SELECT * FROM payments WHERE isDeleted = 0 AND dateEpochDay BETWEEN :startDay AND :endDay ORDER BY dateEpochDay ASC")
    suspend fun getBetween(startDay: Long, endDay: Long): List<Payment>

    @Query("SELECT * FROM payments")
    suspend fun getAll(): List<Payment>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(payment: Payment)

    @Update
    suspend fun update(payment: Payment)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(payments: List<Payment>)

    @Query("UPDATE payments SET isDeleted = 1, updatedAt = :timestamp WHERE id = :id")
    suspend fun softDelete(id: String, timestamp: Long)

    @Query("SELECT COUNT(*) FROM payments WHERE isDeleted = 0")
    suspend fun countActive(): Int

    @Query(
        """
        SELECT COUNT(*) FROM payments
        WHERE isDeleted = 0 AND id != :excludeId AND farmerId = :farmerId
            AND dateEpochDay = :dateEpochDay AND method = :method
            AND ABS(amount - :amount) < 0.01
        """
    )
    suspend fun countPotentialDuplicates(
        farmerId: String,
        dateEpochDay: Long,
        method: String,
        amount: Double,
        excludeId: String
    ): Int

    @Query("DELETE FROM payments")
    suspend fun deleteAllHard()
}

@Dao
interface WorkTypeDao {

    @Query("SELECT * FROM work_types WHERE isDeleted = 0 ORDER BY sortOrder ASC")
    fun observeAll(): Flow<List<WorkTypeRate>>

    @Query("SELECT * FROM work_types WHERE isDeleted = 0 ORDER BY sortOrder ASC")
    suspend fun getAll(): List<WorkTypeRate>

    @Query("SELECT COUNT(*) FROM work_types")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(types: List<WorkTypeRate>)

    @Query("UPDATE work_types SET sortOrder = :sortOrder WHERE id = :id")
    suspend fun setSortOrder(id: String, sortOrder: Int)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(rate: WorkTypeRate)

    @Update
    suspend fun update(rate: WorkTypeRate)

    @Query("DELETE FROM work_types")
    suspend fun deleteAllHard()
}
