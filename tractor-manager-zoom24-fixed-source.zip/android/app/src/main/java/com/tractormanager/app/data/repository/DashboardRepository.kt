package com.tractormanager.app.data.repository

import com.tractormanager.app.core.DateUtils
import com.tractormanager.app.data.local.FarmerDao
import com.tractormanager.app.data.local.PaymentDao
import com.tractormanager.app.data.local.WorkRecordDao
import com.tractormanager.app.data.local.WorkTotals
import com.tractormanager.app.data.repository.FarmerListItem
import com.tractormanager.app.domain.PaymentCalculator
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

data class DashboardData(
    val todayWork: WorkTotals = WorkTotals(0, 0.0, 0.0),
    val monthWork: WorkTotals = WorkTotals(0, 0.0, 0.0),
    val monthReceived: Double = 0.0,
    val totalReceived: Double = 0.0,
    val totalBilled: Double = 0.0,
    val pendingTotal: Double = 0.0,
    val farmerCount: Int = 0,
    val recentWork: List<com.tractormanager.app.data.local.WorkRecordRow> = emptyList(),
    val pendingFarmers: List<FarmerListItem> = emptyList()
)

class DashboardRepository(
    private val workRecordDao: WorkRecordDao,
    private val paymentDao: PaymentDao,
    private val farmerDao: FarmerDao
) {

    fun observeDashboard(today: Long = DateUtils.todayEpochDay()): Flow<DashboardData> {
        val monthStart = DateUtils.monthStartEpochDay(today)
        val monthEnd = DateUtils.monthEndEpochDay(today)

        val totals = combine(
            workRecordDao.observeTotals(today, today),
            workRecordDao.observeTotals(monthStart, monthEnd),
            workRecordDao.observeBilledTotal(),
            paymentDao.observeReceivedTotal(),
            paymentDao.observeReceivedBetween(monthStart, monthEnd)
        ) { todayWork, monthWork, billed, received, monthReceived ->
            TotalsHolder(todayWork, monthWork, billed, received, monthReceived)
        }

        return combine(
            totals,
            farmerDao.observeCountActive(),
            farmerDao.observeWithBalances(),
            workRecordDao.observeRecent(6)
        ) { t, count, balances, recent ->
            val items = balances.map { row ->
                FarmerListItem(
                    farmer = row.farmer,
                    summary = PaymentCalculator.summarize(row.billed, row.received)
                )
            }
            DashboardData(
                todayWork = t.todayWork,
                monthWork = t.monthWork,
                monthReceived = t.monthReceived,
                totalReceived = t.received,
                totalBilled = t.billed,
                pendingTotal = com.tractormanager.app.core.Money.round(items.sumOf { it.summary.outstanding }),
                farmerCount = count,
                recentWork = recent,
                pendingFarmers = items
                    .filter { it.summary.outstanding > 0.0 }
                    .sortedByDescending { it.summary.outstanding }
                    .take(5)
            )
        }
    }

    private data class TotalsHolder(
        val todayWork: WorkTotals,
        val monthWork: WorkTotals,
        val billed: Double,
        val received: Double,
        val monthReceived: Double
    )
}
