package com.tractormanager.app.ui.navigation

import android.net.Uri
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.outlined.Agriculture
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.tractormanager.app.ui.screens.dashboard.DashboardScreen
import com.tractormanager.app.ui.screens.farmers.FarmerDetailScreen
import com.tractormanager.app.ui.screens.farmers.FarmerEditScreen
import com.tractormanager.app.ui.screens.farmers.FarmersScreen
import com.tractormanager.app.ui.screens.map.LandMapScreen
import com.tractormanager.app.ui.screens.payments.PaymentEntryScreen
import com.tractormanager.app.ui.screens.payments.PaymentsScreen
import com.tractormanager.app.ui.screens.reports.ReportsScreen
import com.tractormanager.app.ui.screens.settings.SettingsScreen
import com.tractormanager.app.ui.screens.work.WorkEntryScreen
import com.tractormanager.app.ui.screens.work.WorkListScreen
import com.tractormanager.app.ui.theme.Green100
import com.tractormanager.app.ui.theme.Green700
import com.tractormanager.app.ui.theme.Green900
import com.tractormanager.app.ui.theme.White

object Routes {
    const val DASHBOARD = "dashboard"
    const val FARMERS = "farmers"
    const val WORK = "work"
    const val PAYMENTS = "payments"
    const val REPORTS = "reports"
    const val SETTINGS = "settings"

    const val FARMER_EDIT = "farmer_edit?farmerId={farmerId}"
    const val FARMER_DETAIL = "farmer/{farmerId}"
    const val FIELD_MAP = "field_map?farmerId={farmerId}&fieldId={fieldId}"
    const val WORK_ADD = "work_add?farmerId={farmerId}&fieldId={fieldId}"
    const val PAYMENT_ADD = "payment_add?farmerId={farmerId}"

    fun farmerEdit(farmerId: String? = null): String =
        "farmer_edit?farmerId=${Uri.encode(farmerId.orEmpty())}"

    fun farmerDetail(farmerId: String): String = "farmer/${Uri.encode(farmerId)}"

    fun fieldMap(farmerId: String? = null, fieldId: String? = null): String =
        "field_map?farmerId=${Uri.encode(farmerId.orEmpty())}&fieldId=${Uri.encode(fieldId.orEmpty())}"

    fun workAdd(farmerId: String? = null, fieldId: String? = null): String =
        "work_add?farmerId=${Uri.encode(farmerId.orEmpty())}&fieldId=${Uri.encode(fieldId.orEmpty())}"

    fun paymentAdd(farmerId: String? = null): String =
        "payment_add?farmerId=${Uri.encode(farmerId.orEmpty())}"
}

private data class BottomItem(
    val route: String,
    val label: String,
    val icon: ImageVector
)

private val bottomItems = listOf(
    BottomItem(Routes.DASHBOARD, "डॅशबोर्ड", Icons.Filled.Home),
    BottomItem(Routes.FARMERS, "शेतकरी", Icons.Outlined.Groups),
    BottomItem(Routes.WORK, "काम", Icons.Outlined.Agriculture),
    BottomItem(Routes.PAYMENTS, "पैसे", Icons.Outlined.Payments),
    BottomItem(Routes.REPORTS, "अहवाल", Icons.Outlined.BarChart)
)

private val topLevelRoutes = bottomItems.map { it.route }.toSet()

@Composable
fun MainNavigation() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomBar = currentRoute == null || currentRoute in topLevelRoutes

    fun navigateTop(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(containerColor = White, tonalElevation = 3.dp) {
                    bottomItems.forEach { item ->
                        NavigationBarItem(
                            selected = currentRoute == item.route,
                            onClick = { navigateTop(item.route) },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Green900,
                                selectedTextColor = Green900,
                                indicatorColor = Green100,
                                unselectedIconColor = Green700.copy(alpha = 0.65f),
                                unselectedTextColor = Green700.copy(alpha = 0.65f)
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Routes.DASHBOARD,
            modifier = Modifier.padding(padding)
        ) {
            composable(Routes.DASHBOARD) {
                DashboardScreen(
                    onAddWork = { navController.navigate(Routes.workAdd()) },
                    onAddFarmer = { navController.navigate(Routes.farmerEdit()) },
                    onMeasureLand = { navController.navigate(Routes.fieldMap()) },
                    onShowFarmers = { navController.navigate(Routes.FARMERS) },
                    onShowWork = { navController.navigate(Routes.WORK) },
                    onShowPayments = { navController.navigate(Routes.PAYMENTS) },
                    onShowReports = { navController.navigate(Routes.REPORTS) },
                    onSettings = { navController.navigate(Routes.SETTINGS) },
                    onFarmerClick = { id -> navController.navigate(Routes.farmerDetail(id)) },
                    onWorkClick = { id -> navController.navigate(Routes.farmerDetail(id)) }
                )
            }
            composable(Routes.FARMERS) {
                FarmersScreen(
                    onAddFarmer = { navController.navigate(Routes.farmerEdit()) },
                    onFarmerClick = { id -> navController.navigate(Routes.farmerDetail(id)) }
                )
            }
            composable(Routes.WORK) {
                WorkListScreen(
                    onAddWork = { navController.navigate(Routes.workAdd()) },
                    onFarmerClick = { id -> navController.navigate(Routes.farmerDetail(id)) }
                )
            }
            composable(Routes.PAYMENTS) {
                PaymentsScreen(
                    onAddPayment = { navController.navigate(Routes.paymentAdd()) },
                    onFarmerClick = { id -> navController.navigate(Routes.farmerDetail(id)) }
                )
            }
            composable(Routes.REPORTS) {
                ReportsScreen(onSettings = { navController.navigate(Routes.SETTINGS) })
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(onBack = { navController.popBackStack() })
            }

            composable(
                route = Routes.FARMER_EDIT,
                arguments = listOf(navArgument("farmerId") {
                    type = NavType.StringType
                    defaultValue = ""
                })
            ) { entry ->
                FarmerEditScreen(
                    farmerId = entry.arguments?.getString("farmerId").orEmpty().ifBlank { null },
                    onBack = { navController.popBackStack() },
                    onSaved = { navController.popBackStack() }
                )
            }

            composable(
                route = Routes.FARMER_DETAIL,
                arguments = listOf(navArgument("farmerId") { type = NavType.StringType })
            ) { entry ->
                val farmerId = entry.arguments?.getString("farmerId").orEmpty()
                FarmerDetailScreen(
                    farmerId = farmerId,
                    onBack = { navController.popBackStack() },
                    onEdit = { navController.navigate(Routes.farmerEdit(farmerId)) },
                    onAddField = { navController.navigate(Routes.fieldMap(farmerId = farmerId)) },
                    onEditField = { fieldId ->
                        navController.navigate(Routes.fieldMap(farmerId = farmerId, fieldId = fieldId))
                    },
                    onAddWork = { fieldId ->
                        navController.navigate(Routes.workAdd(farmerId = farmerId, fieldId = fieldId))
                    },
                    onAddPayment = { navController.navigate(Routes.paymentAdd(farmerId = farmerId)) }
                )
            }

            composable(
                route = Routes.FIELD_MAP,
                arguments = listOf(
                    navArgument("farmerId") { type = NavType.StringType; defaultValue = "" },
                    navArgument("fieldId") { type = NavType.StringType; defaultValue = "" }
                )
            ) { entry ->
                LandMapScreen(
                    initialFarmerId = entry.arguments?.getString("farmerId").orEmpty().ifBlank { null },
                    fieldId = entry.arguments?.getString("fieldId").orEmpty().ifBlank { null },
                    onBack = { navController.popBackStack() },
                    onSaved = { navController.popBackStack() },
                    onAddFarmer = { navController.navigate(Routes.farmerEdit()) }
                )
            }

            composable(
                route = Routes.WORK_ADD,
                arguments = listOf(
                    navArgument("farmerId") { type = NavType.StringType; defaultValue = "" },
                    navArgument("fieldId") { type = NavType.StringType; defaultValue = "" }
                )
            ) { entry ->
                WorkEntryScreen(
                    initialFarmerId = entry.arguments?.getString("farmerId").orEmpty().ifBlank { null },
                    initialFieldId = entry.arguments?.getString("fieldId").orEmpty().ifBlank { null },
                    onBack = { navController.popBackStack() },
                    onSaved = { navController.popBackStack() },
                    onAddFarmer = { navController.navigate(Routes.farmerEdit()) },
                    onAddField = { farmerId -> navController.navigate(Routes.fieldMap(farmerId = farmerId)) }
                )
            }

            composable(
                route = Routes.PAYMENT_ADD,
                arguments = listOf(navArgument("farmerId") {
                    type = NavType.StringType
                    defaultValue = ""
                })
            ) { entry ->
                PaymentEntryScreen(
                    initialFarmerId = entry.arguments?.getString("farmerId").orEmpty().ifBlank { null },
                    onBack = { navController.popBackStack() },
                    onSaved = { navController.popBackStack() },
                    onAddFarmer = { navController.navigate(Routes.farmerEdit()) }
                )
            }
        }
    }
}
