package com.tractormanager.app.ui.screens.work

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Agriculture
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tractormanager.app.core.Money
import com.tractormanager.app.core.NumberText
import com.tractormanager.app.ui.appViewModel
import com.tractormanager.app.ui.components.ConfirmDialog
import com.tractormanager.app.ui.components.EmptyState
import com.tractormanager.app.ui.components.ScreenScaffold
import com.tractormanager.app.ui.components.WorkListCard
import com.tractormanager.app.ui.theme.Danger
import com.tractormanager.app.ui.theme.Green100
import com.tractormanager.app.ui.theme.Green50
import com.tractormanager.app.ui.theme.Green700
import com.tractormanager.app.ui.theme.Green900
import com.tractormanager.app.ui.theme.InkSoft
import com.tractormanager.app.ui.theme.White

@Composable
fun WorkListScreen(
    onAddWork: () -> Unit,
    onFarmerClick: (String) -> Unit
) {
    val viewModel = appViewModel { WorkListViewModel(it.workRepository) }
    val rows by viewModel.rows.collectAsStateWithLifecycle()
    val totals by viewModel.totals.collectAsStateWithLifecycle()
    val period by viewModel.period.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var deleteId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    ScreenScaffold(
        title = "कामाचा हिशोब",
        subtitle = "${totals.count} नोंदी • ${NumberText.format(totals.acres, 2)} एकर",
        snackbarHostState = snackbar,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddWork,
                containerColor = Green700,
                contentColor = White,
                icon = { Icon(Icons.Outlined.Add, contentDescription = null) },
                text = { Text("काम नोंदवा") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Surface(
                    color = Green50,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("निवडलेल्या कालावधीतील उत्पन्न", style = MaterialTheme.typography.bodySmall, color = InkSoft)
                            Text(
                                Money.format(totals.amount),
                                style = MaterialTheme.typography.headlineSmall,
                                color = Green900
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("कामे", style = MaterialTheme.typography.bodySmall, color = InkSoft)
                            Text(totals.count.toString(), style = MaterialTheme.typography.headlineSmall, color = Green700)
                        }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    WorkPeriod.entries.forEach { item ->
                        FilterChip(
                            selected = period == item,
                            onClick = { viewModel.setPeriod(item) },
                            label = { Text(item.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Green100,
                                selectedLabelColor = Green900,
                                containerColor = White,
                                labelColor = InkSoft
                            )
                        )
                    }
                }
            }
            if (rows.isEmpty()) {
                item {
                    EmptyState(
                        title = "या कालावधीत काम नाही",
                        message = "ट्रॅक्टरचे काम नोंदवून उत्पन्नाचा हिशोब सुरू करा.",
                        icon = Icons.Outlined.Agriculture,
                        actionLabel = "काम नोंदवा",
                        onAction = onAddWork
                    )
                }
            } else {
                items(rows, key = { it.work.id }) { row ->
                    WorkListCard(
                        row = row,
                        onClick = { onFarmerClick(row.work.farmerId) },
                        trailing = {
                            IconButton(onClick = { deleteId = row.work.id }) {
                                Icon(Icons.Outlined.Delete, contentDescription = "हटवा", tint = Danger)
                            }
                        }
                    )
                }
            }
        }
    }

    val pendingDelete = deleteId
    if (pendingDelete != null) {
        ConfirmDialog(
            title = "कामाची नोंद हटवायची?",
            message = "ही नोंद हटवल्यावर शेतकऱ्याच्या बिलातून रक्कम कमी होईल. बॅकअपमध्ये जुना हिशोब राहील.",
            confirmLabel = "हटवा",
            destructive = true,
            onConfirm = {
                viewModel.deleteWork(pendingDelete)
                deleteId = null
            },
            onDismiss = { deleteId = null }
        )
    }
}
