package com.tractormanager.app.util

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.res.ResourcesCompat
import com.tractormanager.app.R
import com.tractormanager.app.core.DateUtils
import com.tractormanager.app.core.Money
import com.tractormanager.app.core.NumberText
import com.tractormanager.app.data.local.Payment
import com.tractormanager.app.data.local.WorkRecord
import com.tractormanager.app.data.repository.BillData
import com.tractormanager.app.data.repository.MonthReport
import com.tractormanager.app.domain.PaymentStatus
import java.io.File
import java.io.FileOutputStream
import kotlin.math.min

class PdfGenerator(private val context: Context) {

    private val regular: Typeface = ResourcesCompat.getFont(
        context,
        R.font.noto_sans_devanagari_regular
    ) ?: Typeface.SANS_SERIF

    private val bold: Typeface = ResourcesCompat.getFont(
        context,
        R.font.noto_sans_devanagari_bold
    ) ?: Typeface.DEFAULT_BOLD

    private val pageWidth = 595
    private val pageHeight = 842
    private val margin = 36f
    private val bottomLimit = 700f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun pageInfo() = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()

    fun generateBill(data: BillData): File {
        val document = PdfDocument()
        val file = outputFile("bill", data.farmer.name)
        var pageNumber = 1
        var page = document.startPage(pageInfo())
        var canvas = page.canvas
        var y = drawHeader(canvas, "कामाचे बिल", "बिल क्र. ${billNumber(data)}")
        y = drawFarmerBlock(canvas, y + 6f, data)
        y = drawWorkTableHeader(canvas, y + 14f)

        val works = data.works.sortedWith(compareBy({ it.dateEpochDay }, { it.createdAt }))
        if (works.isEmpty()) {
            text(canvas, "या शेतकऱ्याचे काम नोंदवलेले नाही.", margin + 8f, y + 20f, 10f, false, SOFT)
            y += 36f
        } else {
            var index = 0
            while (index < works.size) {
                val maxRows = ((bottomLimit - y) / 24f).toInt().coerceAtLeast(1)
                val take = min(maxRows, works.size - index)
                repeat(take) { offset ->
                    val work = works[index + offset]
                    drawWorkRow(
                        canvas = canvas,
                        top = y,
                        work = work,
                        fieldName = data.fieldNames[work.fieldId].orEmpty(),
                        stripe = (index + offset) % 2 == 0
                    )
                    y += 24f
                }
                index += take
                if (index < works.size) {
                    drawFooter(canvas, pageNumber)
                    document.finishPage(page)
                    pageNumber++
                    page = document.startPage(pageInfo())
                    canvas = page.canvas
                    y = drawHeader(canvas, "कामाचे बिल (पुढे)", data.farmer.name)
                    y = drawWorkTableHeader(canvas, y + 6f)
                }
            }
        }

        if (y > bottomLimit - 34f) {
            drawFooter(canvas, pageNumber)
            document.finishPage(page)
            pageNumber++
            page = document.startPage(pageInfo())
            canvas = page.canvas
            y = drawHeader(canvas, "कामाचे बिल (पुढे)", data.farmer.name)
        }
        y = drawWorkTotals(canvas, y, data.works.sumOf { it.totalAmount })

        if (y > 560f) {
            drawFooter(canvas, pageNumber)
            document.finishPage(page)
            pageNumber++
            page = document.startPage(pageInfo())
            canvas = page.canvas
            y = drawHeader(canvas, "हिशोब", data.farmer.name)
        }
        y = drawPaymentSummary(canvas, y + 14f, data)
        drawPaymentHistory(canvas, y + 8f, data.payments)
        drawFooter(canvas, pageNumber)
        document.finishPage(page)
        FileOutputStream(file).use { document.writeTo(it) }
        document.close()
        return file
    }

    fun generateReceipt(data: BillData, payment: Payment): File {
        val document = PdfDocument()
        val file = outputFile("receipt", data.farmer.name)
        val page = document.startPage(pageInfo())
        val canvas = page.canvas
        var y = drawHeader(canvas, "पैसे मिळाल्याची पावती", "पावती क्र. RCPT-${payment.id.take(6).uppercase()}")
        y += 14f
        text(canvas, "शेतकरी: ${data.farmer.name}", margin, y, 13f, true, INK)
        y += 20f
        text(canvas, "मोबाईल: ${data.farmer.mobile}", margin, y, 11f, false, SOFT)
        y += 18f
        text(canvas, "गाव: ${data.farmer.village.ifBlank { "-" }}", margin, y, 11f, false, SOFT)
        y += 28f

        fill.color = Color.rgb(237, 247, 237)
        canvas.drawRoundRect(RectF(margin, y, pageWidth - margin, y + 84f), 12f, 12f, fill)
        text(canvas, "मिळालेली रक्कम", margin + 16f, y + 24f, 11f, false, SOFT)
        text(canvas, Money.format(payment.amount), margin + 16f, y + 58f, 28f, true, GREEN)
        text(
            canvas,
            "${DateUtils.formatDate(payment.dateEpochDay)} • ${payment.method} • ${payment.kind}",
            pageWidth - margin - 16f,
            y + 34f,
            10f,
            false,
            SOFT,
            Paint.Align.RIGHT
        )
        y += 108f

        y = labeledRow(canvas, "एकूण कामाचे बिल", Money.format(data.summary.totalBilled), y)
        y = labeledRow(canvas, "आतापर्यंत जमा (या पावतीसह)", Money.format(data.summary.totalReceived), y)
        y = labeledRow(
            canvas,
            if (data.summary.advance > 0) "जादा जमा (अ‍ॅडव्हान्स)" else "उर्वरित बाकी",
            if (data.summary.advance > 0) {
                Money.format(data.summary.advance)
            } else {
                Money.format(data.summary.outstanding)
            },
            y
        )
        if (payment.note.isNotBlank()) {
            y += 8f
            text(canvas, "नोंद: ${payment.note}", margin, y, 10f, false, SOFT)
            y += 20f
        }
        text(
            canvas,
            "स्थिती: ${data.summary.status.marathiLabel}",
            margin,
            y + 16f,
            12f,
            true,
            GREEN
        )
        drawFooter(canvas, 1)
        document.finishPage(page)
        FileOutputStream(file).use { document.writeTo(it) }
        document.close()
        return file
    }

    fun generateMonthReport(report: MonthReport): File {
        val document = PdfDocument()
        val file = outputFile("report", "month")
        var pageNumber = 1
        var page = document.startPage(pageInfo())
        var canvas = page.canvas
        var y = drawHeader(canvas, "मासिक अहवाल", DateUtils.formatMonth(report.monthEpochDay))
        y += 12f

        val boxWidth = (pageWidth - margin * 2 - 10f) / 2f
        val boxes = listOf(
            "एकूण कामे" to report.works.size.toString(),
            "एकूण एकर" to NumberText.format(report.totalAcres, 2),
            "महिन्याचे बिल" to Money.format(report.totalBilled),
            "महिन्यात जमा" to Money.format(report.totalReceived),
            "एकूण बाकी (सर्व)" to Money.format(report.totalOutstanding),
            "एकूण शेतकरी" to report.farmers.size.toString()
        )
        boxes.forEachIndexed { index, pair ->
            val column = index % 2
            val row = index / 2
            val x = margin + column * (boxWidth + 10f)
            val top = y + row * 58f
            fill.color = if (index == 4) Color.rgb(255, 243, 214) else Color.rgb(247, 250, 247)
            canvas.drawRoundRect(RectF(x, top, x + boxWidth, top + 50f), 10f, 10f, fill)
            text(canvas, pair.first, x + 12f, top + 18f, 9f, false, SOFT)
            text(canvas, pair.second, x + 12f, top + 40f, 16f, true, INK)
        }
        y += 3 * 58f + 10f

        text(canvas, "शेतकरीनिहाय हिशोब", margin, y + 10f, 12f, true, INK)
        y += 20f
        y = drawReportTableHeader(canvas, y)

        if (report.farmers.isEmpty()) {
            text(canvas, "या महिन्यात कोणतीही नोंद नाही.", margin + 8f, y + 20f, 10f, false, SOFT)
            y += 36f
        } else {
            var index = 0
            while (index < report.farmers.size) {
                val maxRows = ((bottomLimit - y) / 24f).toInt().coerceAtLeast(1)
                val take = min(maxRows, report.farmers.size - index)
                repeat(take) { offset ->
                    drawReportRow(canvas, y, report.farmers[index + offset], (index + offset) % 2 == 0)
                    y += 24f
                }
                index += take
                if (index < report.farmers.size) {
                    drawFooter(canvas, pageNumber)
                    document.finishPage(page)
                    pageNumber++
                    page = document.startPage(pageInfo())
                    canvas = page.canvas
                    y = drawHeader(canvas, "मासिक अहवाल (पुढे)", report.monthLabel)
                    y += 6f
                    y = drawReportTableHeader(canvas, y)
                }
            }
        }
        drawFooter(canvas, pageNumber)
        document.finishPage(page)
        FileOutputStream(file).use { document.writeTo(it) }
        document.close()
        return file
    }

    private fun drawHeader(canvas: Canvas, title: String, subtitle: String): Float {
        fill.color = GREEN
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 86f, fill)
        text(canvas, "ट्रॅक्टर मॅनेजर", margin, 33f, 19f, true, Color.WHITE)
        text(canvas, "शेती कामाचे हिशोब, सोप्या मराठीत", margin, 50f, 8.5f, false, Color.rgb(215, 239, 216))
        text(canvas, title, pageWidth - margin, 30f, 17f, true, Color.WHITE, Paint.Align.RIGHT)
        text(canvas, subtitle, pageWidth - margin, 50f, 9.5f, false, Color.rgb(215, 239, 216), Paint.Align.RIGHT)
        text(
            canvas,
            "दिनांक: ${DateUtils.formatDate(DateUtils.todayEpochDay())}",
            pageWidth - margin,
            68f,
            8.5f,
            false,
            Color.WHITE,
            Paint.Align.RIGHT
        )
        return 100f
    }

    private fun drawFarmerBlock(canvas: Canvas, top: Float, data: BillData): Float {
        fill.color = Color.rgb(247, 250, 247)
        canvas.drawRoundRect(RectF(margin, top, pageWidth - margin, top + 66f), 10f, 10f, fill)
        text(canvas, "शेतकरी: ${data.farmer.name}", margin + 14f, top + 22f, 12f, true, INK)
        text(canvas, "मोबाईल: ${data.farmer.mobile}", margin + 14f, top + 40f, 10f, false, SOFT)
        text(canvas, "गाव: ${data.farmer.village.ifBlank { "-" }}", margin + 14f, top + 56f, 10f, false, SOFT)
        text(
            canvas,
            "स्थिती: ${data.summary.status.marathiLabel}",
            pageWidth - margin - 14f,
            top + 24f,
            11f,
            true,
            statusColor(data.summary.status),
            Paint.Align.RIGHT
        )
        text(
            canvas,
            "एकूण बाकी: ${Money.format(data.summary.outstanding)}",
            pageWidth - margin - 14f,
            top + 44f,
            10f,
            false,
            SOFT,
            Paint.Align.RIGHT
        )
        return top + 66f
    }

    private val workColumns = floatArrayOf(36f, 150f, 244f, 326f, 372f, 436f)
    private val workWidths = floatArrayOf(110f, 90f, 78f, 42f, 60f, 123f)

    private fun drawWorkTableHeader(canvas: Canvas, top: Float): Float {
        fill.color = GREEN
        canvas.drawRect(margin, top, pageWidth - margin, top + 26f, fill)
        val titles = listOf("काम", "शेत", "दिनांक", "एकर", "दर", "रक्कम")
        titles.forEachIndexed { index, title ->
            val align = if (index >= 3) Paint.Align.RIGHT else Paint.Align.LEFT
            val x = if (index >= 3) workColumns[index] + workWidths[index] - 6f else workColumns[index]
            text(canvas, title, x, top + 17f, 9f, true, Color.WHITE, align)
        }
        return top + 26f
    }

    private fun drawWorkRow(canvas: Canvas, top: Float, work: WorkRecord, fieldName: String, stripe: Boolean) {
        if (stripe) {
            fill.color = Color.rgb(247, 250, 247)
            canvas.drawRect(margin, top, pageWidth - margin, top + 24f, fill)
        }
        val values = listOf(
            fitText(work.workTypeName, workWidths[0] - 8f),
            fitText(fieldName.ifBlank { "-" }, workWidths[1] - 8f),
            DateUtils.formatDateShort(work.dateEpochDay),
            NumberText.format(work.acres, 2),
            Money.formatPlain(work.ratePerAcre),
            Money.formatPlain(work.totalAmount)
        )
        values.forEachIndexed { column, value ->
            val align = if (column == 5) Paint.Align.RIGHT else Paint.Align.LEFT
            val x = if (column == 5) {
                workColumns[column] + workWidths[column] - 6f
            } else {
                workColumns[column]
            }
            text(canvas, value, x, top + 16f, 9f, false, INK, align)
        }
    }

    private fun drawWorkTotals(canvas: Canvas, top: Float, total: Double): Float {
        fill.color = Color.rgb(215, 239, 216)
        canvas.drawRect(margin, top, pageWidth - margin, top + 28f, fill)
        text(canvas, "एकूण", margin + 8f, top + 18f, 10f, true, DARK_GREEN)
        text(
            canvas,
            Money.format(total),
            workColumns[5] + workWidths[5] - 6f,
            top + 18f,
            10f,
            true,
            DARK_GREEN,
            Paint.Align.RIGHT
        )
        return top + 28f
    }

    private fun drawPaymentSummary(canvas: Canvas, top: Float, data: BillData): Float {
        var y = top
        y = labeledRow(canvas, "एकूण बिल", Money.format(data.summary.totalBilled), y)
        y = labeledRow(canvas, "एकूण जमा", Money.format(data.summary.totalReceived), y)
        if (data.summary.advance > 0) {
            y = labeledRow(canvas, "जादा जमा / अ‍ॅडव्हान्स", Money.format(data.summary.advance), y)
        }
        fill.color = Color.rgb(237, 247, 237)
        canvas.drawRoundRect(RectF(margin, y, pageWidth - margin, y + 44f), 10f, 10f, fill)
        text(canvas, "उर्वरित बाकी", margin + 14f, y + 27f, 12f, true, DARK_GREEN)
        text(
            canvas,
            Money.format(data.summary.outstanding),
            pageWidth - margin - 14f,
            y + 28f,
            16f,
            true,
            GREEN,
            Paint.Align.RIGHT
        )
        return y + 44f
    }

    private fun drawPaymentHistory(canvas: Canvas, top: Float, payments: List<Payment>): Float {
        var y = top
        if (payments.isNotEmpty()) {
            text(canvas, "जमा इतिहास", margin, y + 10f, 11f, true, INK)
            y += 20f
            payments.sortedBy { it.dateEpochDay }.takeLast(8).forEach { payment ->
                if (y > 780f) return y
                text(
                    canvas,
                    "${DateUtils.formatDateShort(payment.dateEpochDay)} • ${payment.method} • ${payment.kind}",
                    margin,
                    y,
                    9f,
                    false,
                    SOFT
                )
                text(
                    canvas,
                    Money.format(payment.amount),
                    pageWidth - margin,
                    y,
                    9f,
                    false,
                    INK,
                    Paint.Align.RIGHT
                )
                y += 16f
            }
        }
        return y
    }

    private val reportColumns = floatArrayOf(36f, 206f, 291f, 367f, 453f)
    private val reportWidths = floatArrayOf(170f, 85f, 76f, 86f, 106f)

    private fun drawReportTableHeader(canvas: Canvas, top: Float): Float {
        fill.color = GREEN
        canvas.drawRect(margin, top, pageWidth - margin, top + 26f, fill)
        val titles = listOf("शेतकरी", "महिन्याचे बिल", "महिन्याची जमा", "एकूण बाकी", "स्थिती")
        titles.forEachIndexed { index, title ->
            val align = if (index == 0) Paint.Align.LEFT else Paint.Align.RIGHT
            val x = if (index == 0) reportColumns[index] else reportColumns[index] + reportWidths[index] - 6f
            text(canvas, title, x, top + 17f, 9f, true, Color.WHITE, align)
        }
        return top + 26f
    }

    private fun drawReportRow(canvas: Canvas, top: Float, row: com.tractormanager.app.data.repository.FarmerReportRow, stripe: Boolean) {
        if (stripe) {
            fill.color = Color.rgb(247, 250, 247)
            canvas.drawRect(margin, top, pageWidth - margin, top + 24f, fill)
        }
        val values = listOf(
            fitText(row.name, reportWidths[0] - 8f),
            Money.formatPlain(row.monthBilled),
            Money.formatPlain(row.monthReceived),
            Money.formatPlain(row.totalOutstanding),
            row.status.marathiLabel
        )
        values.forEachIndexed { index, value ->
            val align = if (index == 0) Paint.Align.LEFT else Paint.Align.RIGHT
            val x = if (index == 0) reportColumns[index] else reportColumns[index] + reportWidths[index] - 6f
            text(canvas, value, x, top + 16f, 9f, false, INK, align)
        }
    }

    private fun labeledRow(canvas: Canvas, label: String, value: String, top: Float): Float {
        text(canvas, label, margin, top + 12f, 10f, false, SOFT)
        text(canvas, value, pageWidth - margin, top + 12f, 11f, true, INK, Paint.Align.RIGHT)
        fill.color = Color.rgb(228, 236, 226)
        canvas.drawRect(margin, top + 19f, pageWidth - margin, top + 20f, fill)
        return top + 26f
    }

    private fun drawFooter(canvas: Canvas, pageNumber: Int) {
        fill.color = Color.rgb(228, 236, 226)
        canvas.drawRect(margin, pageHeight - 42f, pageWidth - margin, pageHeight - 41f, fill)
        text(
            canvas,
            "ट्रॅक्टर मॅनेजर • हिशोब विश्वासाने, काम वेळेवर",
            margin,
            pageHeight - 25f,
            8f,
            false,
            SOFT
        )
        text(
            canvas,
            "पान $pageNumber",
            pageWidth - margin,
            pageHeight - 25f,
            8f,
            false,
            SOFT,
            Paint.Align.RIGHT
        )
    }

    private fun text(
        canvas: Canvas,
        value: String,
        x: Float,
        y: Float,
        size: Float,
        isBold: Boolean,
        color: Int,
        align: Paint.Align = Paint.Align.LEFT
    ) {
        paint.textSize = size
        paint.typeface = if (isBold) bold else regular
        paint.color = color
        paint.textAlign = align
        canvas.drawText(value, x, y, paint)
    }

    private fun fitText(value: String, maxWidth: Float): String {
        paint.textSize = 9f
        paint.typeface = regular
        if (paint.measureText(value) <= maxWidth) return value
        var text = value
        while (text.length > 1 && paint.measureText("$text…") > maxWidth) {
            text = text.dropLast(1)
        }
        return "$text…"
    }

    private fun statusColor(status: PaymentStatus): Int = when (status) {
        PaymentStatus.PAID -> GREEN
        PaymentStatus.PARTIAL -> Color.rgb(239, 108, 0)
        PaymentStatus.UNPAID -> Color.rgb(179, 38, 30)
        PaymentStatus.NO_DUE -> SOFT
    }

    private fun billNumber(data: BillData): String =
        "BILL-${DateUtils.todayEpochDay()}-${data.farmer.id.take(4).uppercase()}"

    private fun outputFile(prefix: String, name: String): File {
        val dir = File(context.cacheDir, "bills").apply { mkdirs() }
        val safeName = name.replace(Regex("[^\\p{L}\\p{N}_-]"), "_").take(40)
        return File(
            dir,
            "${prefix}_${safeName}_${DateUtils.fileStamp()}_${System.currentTimeMillis() % 10000}.pdf"
        )
    }

    private companion object {
        val GREEN = Color.rgb(46, 125, 50)
        val DARK_GREEN = Color.rgb(16, 59, 20)
        val INK = Color.rgb(23, 37, 26)
        val SOFT = Color.rgb(80, 96, 79)
    }
}
