package com.tractormanager.app.domain

import com.tractormanager.app.core.Money

enum class PaymentStatus(val marathiLabel: String) {
    PAID("पूर्ण झाले"),
    PARTIAL("अर्धवट"),
    UNPAID("बाकी"),
    NO_DUE("काम नाही")
}

data class PaymentSummary(
    val totalBilled: Double,
    val totalReceived: Double,
    val balance: Double,
    val outstanding: Double,
    val advance: Double,
    val status: PaymentStatus
)

object BillingCalculator {
    fun total(acres: Double, ratePerAcre: Double): Double {
        if (acres <= 0 || ratePerAcre < 0) return 0.0
        return Money.multiply(acres, ratePerAcre)
    }
}

object PaymentCalculator {

    fun summarize(totalBilled: Double, totalReceived: Double): PaymentSummary {
        val billed = Money.round(totalBilled.coerceAtLeast(0.0))
        val received = Money.round(totalReceived.coerceAtLeast(0.0))
        val balance = Money.round(billed - received)
        val outstanding = Money.round(balance.coerceAtLeast(0.0))
        val advance = Money.round((received - billed).coerceAtLeast(0.0))
        val status = when {
            billed <= 0.0 && received <= 0.0 -> PaymentStatus.NO_DUE
            outstanding <= 0.009 -> PaymentStatus.PAID
            received <= 0.009 -> PaymentStatus.UNPAID
            else -> PaymentStatus.PARTIAL
        }
        return PaymentSummary(
            totalBilled = billed,
            totalReceived = received,
            balance = balance,
            outstanding = outstanding,
            advance = advance,
            status = status
        )
    }

    fun paymentKindFor(
        billed: Double,
        alreadyReceived: Double,
        newPayment: Double
    ): String {
        val remaining = (billed - alreadyReceived).coerceAtLeast(0.0)
        return when {
            remaining <= 0.0 -> "अ‍ॅडव्हान्स"
            newPayment + 0.009 >= remaining -> "पूर्ण"
            alreadyReceived > 0.0 -> "आंशिक"
            else -> "अ‍ॅडव्हान्स"
        }
    }
}
