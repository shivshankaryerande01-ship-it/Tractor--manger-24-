package com.tractormanager.app.ui.screens.work

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tractormanager.app.core.DateUtils
import com.tractormanager.app.core.DuplicateRecordException
import com.tractormanager.app.core.NumberText
import com.tractormanager.app.core.ValidationFailureException
import com.tractormanager.app.data.local.Farmer
import com.tractormanager.app.data.local.LandField
import com.tractormanager.app.data.local.WorkTypeRate
import com.tractormanager.app.data.repository.FarmerRepository
import com.tractormanager.app.data.repository.FieldRepository
import com.tractormanager.app.data.repository.WorkRepository
import com.tractormanager.app.data.repository.WorkTypeRepository
import com.tractormanager.app.domain.BillingCalculator
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class WorkEntryState(
    val farmers: List<Farmer> = emptyList(),
    val fields: List<LandField> = emptyList(),
    val fieldsLoading: Boolean = true,
    val workTypes: List<WorkTypeRate> = emptyList(),
    val selectedFarmerId: String = "",
    val selectedFieldId: String = "",
    val selectedWorkTypeId: String = "",
    val dateEpochDay: Long = DateUtils.todayEpochDay(),
    val acresText: String = "",
    val rateText: String = "",
    val notes: String = "",
    val total: Double = 0.0,
    val saving: Boolean = false,
    val errors: Map<String, String> = emptyMap(),
    val message: String? = null,
    val saved: Boolean = false
)

@OptIn(ExperimentalCoroutinesApi::class)
class WorkEntryViewModel(
    private val initialFarmerId: String?,
    private val initialFieldId: String?,
    private val farmerRepository: FarmerRepository,
    private val fieldRepository: FieldRepository,
    private val workTypeRepository: WorkTypeRepository,
    private val workRepository: WorkRepository
) : ViewModel() {

    private val _state = MutableStateFlow(WorkEntryState())
    val state: StateFlow<WorkEntryState> = _state.asStateFlow()

    private var pendingInitialFieldId: String? = initialFieldId
    private val lastRateByType = mutableMapOf<String, String>()

    init {
        viewModelScope.launch {
            farmerRepository.observeFarmers().collect { farmers ->
                _state.update { current ->
                    val selected = current.selectedFarmerId.ifBlank {
                        initialFarmerId?.takeIf { id -> farmers.any { it.id == id } }
                            ?: farmers.firstOrNull()?.id.orEmpty()
                    }
                    current.copy(
                        farmers = farmers,
                        selectedFarmerId = if (farmers.any { it.id == selected }) selected else farmers.firstOrNull()?.id.orEmpty()
                    )
                }
            }
        }
        viewModelScope.launch {
            workTypeRepository.observeAll().collect { types ->
                _state.update { current ->
                    if (current.selectedWorkTypeId.isBlank() && types.isNotEmpty()) {
                        val selectedType = types.first()
                        current.copy(
                            workTypes = types,
                            selectedWorkTypeId = selectedType.id,
                            rateText = rateFor(selectedType, current.rateText)
                        )
                    } else {
                        current.copy(workTypes = types)
                    }
                }
            }
        }
        viewModelScope.launch {
            _state.map { it.selectedFarmerId }
                .distinctUntilChanged()
                .flatMapLatest { farmerId ->
                    if (farmerId.isBlank()) flowOf(emptyList()) else fieldRepository.observeByFarmer(farmerId)
                }
                .collect { fields -> applyFields(fields) }
        }
    }

    private fun applyFields(fields: List<LandField>) {
        _state.update { current ->
            val keep = current.selectedFieldId.takeIf { id -> fields.any { it.id == id } }
            val initial = pendingInitialFieldId?.takeIf { id -> fields.any { it.id == id } }
            if (initial != null) pendingInitialFieldId = null
            val chosen = keep ?: initial ?: fields.firstOrNull()?.id.orEmpty()
            val field = fields.firstOrNull { it.id == chosen }
            val acres = when {
                field == null -> ""
                current.acresText.isBlank() || current.selectedFieldId != chosen ->
                    NumberText.format(field.areaAcres, 3)
                else -> current.acresText
            }
            current.copy(
                fields = fields,
                fieldsLoading = false,
                selectedFieldId = chosen,
                acresText = acres,
                total = computeTotal(acres, current.rateText),
                errors = current.errors - "field"
            )
        }
    }

    fun onFarmerSelected(id: String) {
        _state.update {
            it.copy(
                selectedFarmerId = id,
                selectedFieldId = "",
                fields = emptyList(),
                fieldsLoading = true,
                acresText = "",
                total = 0.0,
                errors = it.errors - "farmer" - "field"
            )
        }
    }

    fun onFieldSelected(id: String) {
        val field = _state.value.fields.firstOrNull { it.id == id }
        val acres = field?.let { NumberText.format(it.areaAcres, 3) }.orEmpty()
        _state.update {
            it.copy(
                selectedFieldId = id,
                acresText = acres,
                total = computeTotal(acres, it.rateText),
                errors = it.errors - "field" - "acres"
            )
        }
    }

    fun onWorkTypeSelected(id: String) {
        val type = _state.value.workTypes.firstOrNull { it.id == id } ?: return
        val rate = lastRateByType[id] ?: NumberText.format(type.defaultRate, 2)
        _state.update {
            it.copy(
                selectedWorkTypeId = id,
                rateText = rate,
                total = computeTotal(it.acresText, rate),
                errors = it.errors - "workType" - "rate"
            )
        }
    }

    fun onDateSelected(epochDay: Long) {
        _state.update { it.copy(dateEpochDay = epochDay, errors = it.errors - "date") }
    }

    fun onAcresChange(value: String) {
        val clean = value.filter { it.isDigit() || it == '.' }.take(12)
        _state.update {
            it.copy(
                acresText = clean,
                total = computeTotal(clean, it.rateText),
                errors = it.errors - "acres"
            )
        }
    }

    fun onRateChange(value: String) {
        val clean = value.filter { it.isDigit() || it == '.' }.take(12)
        _state.update {
            if (it.selectedWorkTypeId.isNotBlank()) {
                lastRateByType[it.selectedWorkTypeId] = clean
            }
            it.copy(
                rateText = clean,
                total = computeTotal(it.acresText, clean),
                errors = it.errors - "rate"
            )
        }
    }

    fun onNotesChange(value: String) = _state.update { it.copy(notes = value) }

    fun save() {
        if (_state.value.saving) return
        val current = _state.value
        val acres = current.acresText.toDoubleOrNull()
        val rate = current.rateText.toDoubleOrNull()
        val localErrors = mutableMapOf<String, String>()
        if (acres == null) localErrors["acres"] = "वैध एकर टाका."
        if (rate == null) localErrors["rate"] = "वैध दर टाका."
        if (localErrors.isNotEmpty()) {
            _state.update { it.copy(errors = localErrors, message = localErrors.values.first()) }
            return
        }
        val workType = current.workTypes.firstOrNull { it.id == current.selectedWorkTypeId }
        if (workType == null) {
            _state.update { it.copy(message = "कामाचा प्रकार निवडा.") }
            return
        }

        _state.update { it.copy(saving = true, message = null, errors = emptyMap()) }
        viewModelScope.launch {
            workRepository.saveWork(
                id = null,
                farmerId = current.selectedFarmerId,
                fieldId = current.selectedFieldId,
                workTypeId = workType.id,
                workTypeName = workType.name,
                dateEpochDay = current.dateEpochDay,
                acres = acres,
                ratePerAcre = rate,
                notes = current.notes
            ).fold(
                onSuccess = { _state.update { it.copy(saving = false, saved = true) } },
                onFailure = { error ->
                    when (error) {
                        is ValidationFailureException -> _state.update {
                            it.copy(
                                saving = false,
                                errors = error.result.errors,
                                message = error.result.errors.values.firstOrNull()
                            )
                        }
                        is DuplicateRecordException -> _state.update {
                            it.copy(saving = false, message = error.message)
                        }
                        else -> _state.update {
                            it.copy(saving = false, message = error.message ?: "काम जतन करता आले नाही.")
                        }
                    }
                }
            )
        }
    }

    fun clearMessage() = _state.update { it.copy(message = null) }

    private fun computeTotal(acresText: String, rateText: String): Double {
        val acres = acresText.toDoubleOrNull() ?: return 0.0
        val rate = rateText.toDoubleOrNull() ?: return 0.0
        return BillingCalculator.total(acres, rate)
    }

    private fun rateFor(type: WorkTypeRate, current: String): String =
        if (current.isBlank()) NumberText.format(type.defaultRate, 2) else current
}
