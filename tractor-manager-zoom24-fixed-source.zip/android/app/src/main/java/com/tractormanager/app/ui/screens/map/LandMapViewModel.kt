package com.tractormanager.app.ui.screens.map

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tractormanager.app.core.AreaResult
import com.tractormanager.app.core.AreaUnits
import com.tractormanager.app.core.ValidationFailureException
import com.tractormanager.app.core.geo.GeoPoint
import com.tractormanager.app.data.local.Farmer
import com.tractormanager.app.data.place.PlaceResult
import com.tractormanager.app.data.place.PlaceSearchRepository
import com.tractormanager.app.data.repository.FarmerRepository
import com.tractormanager.app.data.repository.FieldRepository
import com.tractormanager.app.data.repository.LandFieldInput
import com.tractormanager.app.util.LocationHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MapCameraTarget(
    val point: GeoPoint,
    val zoom: Double,
    val id: Int
)

data class LandMapState(
    val farmers: List<Farmer> = emptyList(),
    val selectedFarmerId: String = "",
    val fieldId: String? = null,
    val fieldName: String = "",
    val village: String = "",
    val notes: String = "",
    val points: List<GeoPoint> = emptyList(),
    val area: AreaResult = AreaResult(0.0, 0.0, 0.0, 0.0),
    val loading: Boolean = false,
    val saving: Boolean = false,
    val locating: Boolean = false,
    val errors: Map<String, String> = emptyMap(),
    val message: String? = null,
    val saved: Boolean = false,
    val deleted: Boolean = false,
    val searchQuery: String = "",
    val searchResults: List<PlaceResult> = emptyList(),
    val searching: Boolean = false,
    val currentLocation: GeoPoint? = null,
    val locationAccuracyMeters: Float? = null,
    val cameraTarget: MapCameraTarget? = null,
    val selectedPointIndex: Int? = null,
    val manualLatText: String = "",
    val manualLonText: String = ""
)

class LandMapViewModel(
    private val fieldId: String?,
    private val initialFarmerId: String?,
    private val fieldRepository: FieldRepository,
    private val farmerRepository: FarmerRepository,
    private val placeSearchRepository: PlaceSearchRepository,
    private val locationHelper: LocationHelper
) : ViewModel() {

    private val _state = MutableStateFlow(LandMapState(fieldId = fieldId, loading = fieldId != null))
    val state: StateFlow<LandMapState> = _state.asStateFlow()
    private var cameraCounter = 0

    init {
        viewModelScope.launch {
            farmerRepository.observeFarmers().collect { farmers ->
                _state.update { current ->
                    val selected = current.selectedFarmerId.ifBlank {
                        initialFarmerId?.takeIf { id -> farmers.any { it.id == id } }
                            ?: farmers.firstOrNull()?.id.orEmpty()
                    }
                    current.copy(
                        farmers = farmers,
                        selectedFarmerId = if (farmers.any { it.id == selected }) selected else farmers.firstOrNull()?.id.orEmpty()
                    )
                }
            }
        }
        if (fieldId != null) {
            viewModelScope.launch {
                val field = fieldRepository.getField(fieldId)
                if (field == null || field.isDeleted) {
                    _state.update {
                        it.copy(loading = false, message = "जमीन सापडली नाही. कदाचित ती हटवली गेली आहे.")
                    }
                } else {
                    val points = fieldRepository.pointsOf(field)
                    val area = fieldRepository.measure(points)
                    _state.update {
                        it.copy(
                            loading = false,
                            fieldName = field.name,
                            village = field.village,
                            notes = field.notes,
                            selectedFarmerId = field.farmerId,
                            points = points,
                            area = area,
                            cameraTarget = points.centroid()?.let { point ->
                                MapCameraTarget(point, 17.0, ++cameraCounter)
                            }
                        )
                    }
                }
            }
        }
    }

    fun onFieldNameChange(value: String) = _state.update {
        it.copy(fieldName = value, errors = it.errors - "name", message = null)
    }

    fun onVillageChange(value: String) = _state.update {
        it.copy(village = value, errors = it.errors - "village", message = null)
    }

    fun onNotesChange(value: String) = _state.update { it.copy(notes = value) }

    fun onFarmerSelected(id: String) = _state.update {
        it.copy(selectedFarmerId = id, errors = it.errors - "farmer")
    }

    fun addPoint(point: GeoPoint) {
        _state.update { current ->
            val points = current.points + point
            current.copy(
                points = points,
                area = AreaUnits.measure(points),
                errors = current.errors - "points" - "area",
                message = null
            )
        }
    }

    fun undoPoint() {
        _state.update { current ->
            val points = current.points.dropLast(1)
            current.copy(
                points = points,
                area = AreaUnits.measure(points),
                errors = current.errors - "points" - "area"
            )
        }
    }

    fun clearPoints() {
        _state.update {
            it.copy(
                points = emptyList(),
                area = AreaUnits.measure(emptyList()),
                selectedPointIndex = null,
                manualLatText = "",
                manualLonText = "",
                errors = it.errors - "points" - "area"
            )
        }
    }

    fun updatePoint(index: Int, point: GeoPoint) {
        _state.update { current ->
            if (index !in current.points.indices) return@update current
            val points = current.points.toMutableList().also { it[index] = point }
            current.copy(
                points = points,
                area = AreaUnits.measure(points),
                selectedPointIndex = index,
                manualLatText = formatCoordinate(point.latitude),
                manualLonText = formatCoordinate(point.longitude),
                errors = current.errors - "points" - "area" - "coordinate",
                message = null
            )
        }
    }

    fun deletePoint(index: Int) {
        _state.update { current ->
            if (index !in current.points.indices) return@update current
            val points = current.points.toMutableList().also { it.removeAt(index) }
            val selection = when {
                current.selectedPointIndex == null -> null
                current.selectedPointIndex == index -> null
                current.selectedPointIndex!! > index -> current.selectedPointIndex - 1
                else -> current.selectedPointIndex
            }
            val selected = selection?.let { points.getOrNull(it) }
            current.copy(
                points = points,
                area = AreaUnits.measure(points),
                selectedPointIndex = selection,
                manualLatText = selected?.let { formatCoordinate(it.latitude) }.orEmpty(),
                manualLonText = selected?.let { formatCoordinate(it.longitude) }.orEmpty(),
                errors = current.errors - "points" - "area" - "coordinate",
                message = null
            )
        }
    }

    fun selectPoint(index: Int) {
        _state.update { current ->
            val point = current.points.getOrNull(index) ?: return@update current
            current.copy(
                selectedPointIndex = index,
                manualLatText = formatCoordinate(point.latitude),
                manualLonText = formatCoordinate(point.longitude),
                errors = current.errors - "coordinate"
            )
        }
    }

    fun clearPointSelection() = _state.update {
        it.copy(selectedPointIndex = null, manualLatText = "", manualLonText = "")
    }

    fun onManualLatChange(value: String) = _state.update {
        it.copy(manualLatText = value, errors = it.errors - "coordinate")
    }

    fun onManualLonChange(value: String) = _state.update {
        it.copy(manualLonText = value, errors = it.errors - "coordinate")
    }

    fun applyManualPoint() {
        val current = _state.value
        val index = current.selectedPointIndex ?: return
        val lat = current.manualLatText.trim().toDoubleOrNull()
        val lon = current.manualLonText.trim().toDoubleOrNull()
        if (lat == null || lon == null || lat !in -90.0..90.0 || lon !in -180.0..180.0) {
            _state.update {
                it.copy(
                    errors = it.errors + (
                        "coordinate" to "अक्षांश -९० ते ९० आणि रेखांश -१८० ते १८० दरम्यान असावा."
                        )
                )
            }
            return
        }
        updatePoint(index, GeoPoint(lat, lon))
        _state.update {
            it.copy(cameraTarget = MapCameraTarget(GeoPoint(lat, lon), 18.0, ++cameraCounter))
        }
    }

    fun locate() {
        if (_state.value.locating) return
        _state.update { it.copy(locating = true, message = null) }
        viewModelScope.launch {
            locationHelper.currentFix().fold(
                onSuccess = { fix ->
                    _state.update {
                        it.copy(
                            locating = false,
                            currentLocation = fix.point,
                            locationAccuracyMeters = fix.accuracyMeters,
                            cameraTarget = MapCameraTarget(fix.point, 18.0, ++cameraCounter)
                        )
                    }
                },
                onFailure = { error ->
                    _state.update {
                        it.copy(
                            locating = false,
                            message = error.message ?: "GPS स्थान मिळाले नाही."
                        )
                    }
                }
            )
        }
    }

    fun onSearchQueryChange(value: String) = _state.update {
        it.copy(searchQuery = value, searchResults = emptyList())
    }

    fun search() {
        val query = _state.value.searchQuery.trim()
        if (_state.value.searching) return
        if (query.length < 2) {
            _state.update { it.copy(message = "शोधण्यासाठी किमान २ अक्षरे टाका.") }
            return
        }
        _state.update { it.copy(searching = true, searchResults = emptyList(), message = null) }
        viewModelScope.launch {
            placeSearchRepository.search(query).fold(
                onSuccess = { results ->
                    _state.update {
                        it.copy(
                            searching = false,
                            searchResults = results,
                            message = if (results.isEmpty()) "हे ठिकाण सापडले नाही. दुसरे नाव वापरा." else null
                        )
                    }
                },
                onFailure = { error ->
                    _state.update {
                        it.copy(
                            searching = false,
                            message = error.message ?: "ठिकाण शोधता आले नाही."
                        )
                    }
                }
            )
        }
    }

    fun selectPlace(place: PlaceResult) {
        _state.update {
            it.copy(
                searchQuery = place.name,
                searchResults = emptyList(),
                village = if (it.village.isBlank()) place.name else it.village,
                cameraTarget = MapCameraTarget(
                    GeoPoint(place.latitude, place.longitude),
                    16.0,
                    ++cameraCounter
                )
            )
        }
    }

    fun save() {
        if (_state.value.saving) return
        val current = _state.value
        if (current.selectedFarmerId.isBlank()) {
            _state.update {
                it.copy(
                    errors = it.errors + ("farmer" to "जमीन जतन करण्यापूर्वी शेतकरी निवडा."),
                    message = "जमीन जतन करण्यापूर्वी शेतकरी निवडा."
                )
            }
            return
        }
        _state.update { it.copy(saving = true, message = null, errors = emptyMap()) }
        viewModelScope.launch {
            val result = fieldRepository.saveField(
                id = fieldId,
                input = LandFieldInput(
                    farmerId = current.selectedFarmerId,
                    name = current.fieldName,
                    village = current.village,
                    points = current.points,
                    notes = current.notes
                )
            )
            result.fold(
                onSuccess = {
                    _state.update { it.copy(saving = false, saved = true) }
                },
                onFailure = { error ->
                    when (error) {
                        is ValidationFailureException -> _state.update {
                            it.copy(
                                saving = false,
                                errors = error.result.errors,
                                message = error.result.errors.values.firstOrNull()
                            )
                        }
                        else -> _state.update {
                            it.copy(
                                saving = false,
                                message = error.message ?: "जमीन जतन करता आली नाही."
                            )
                        }
                    }
                }
            )
        }
    }

    fun deleteField() {
        val id = fieldId ?: return
        viewModelScope.launch {
            fieldRepository.deleteField(id).fold(
                onSuccess = { _state.update { it.copy(deleted = true) } },
                onFailure = { _state.update { it.copy(message = it.message ?: "जमीन हटवता आली नाही.") } }
            )
        }
    }

    fun clearMessage() {
        _state.update { it.copy(message = null) }
    }
}

internal fun formatCoordinate(value: Double): String =
    String.format(java.util.Locale.US, "%.6f", value)

fun List<GeoPoint>.centroid(): GeoPoint? {
    if (isEmpty()) return null
    return GeoPoint(
        latitude = sumOf { it.latitude } / size,
        longitude = sumOf { it.longitude } / size
    )
}
