package com.tractormanager.app.ui.screens.work

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tractormanager.app.core.DateUtils
import com.tractormanager.app.core.Money
import com.tractormanager.app.data.local.WorkRecordRow
import com.tractormanager.app.data.repository.WorkRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class WorkPeriod(val label: String) {
    TODAY("आज"),
    MONTH("हा महिना"),
    ALL("सर्व")
}

data class WorkListTotals(
    val count: Int = 0,
    val acres: Double = 0.0,
    val amount: Double = 0.0
)

@OptIn(ExperimentalCoroutinesApi::class)
class WorkListViewModel(private val repository: WorkRepository) : ViewModel() {

    private val _period = MutableStateFlow(WorkPeriod.MONTH)
    val period: StateFlow<WorkPeriod> = _period.asStateFlow()

    val rows = _period.flatMapLatest { selected ->
        val today = DateUtils.todayEpochDay()
        when (selected) {
            WorkPeriod.TODAY -> repository.observeBetween(today, today)
            WorkPeriod.MONTH -> repository.observeBetween(
                DateUtils.monthStartEpochDay(today),
                DateUtils.monthEndEpochDay(today)
            )
            WorkPeriod.ALL -> repository.observeAll()
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList()
    )

    val totals = rows.map { list ->
        WorkListTotals(
            count = list.size,
            acres = list.sumOf { it.work.acres },
            amount = Money.round(list.sumOf { it.work.totalAmount })
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = WorkListTotals()
    )

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    fun setPeriod(period: WorkPeriod) {
        _period.value = period
    }

    fun deleteWork(id: String) {
        viewModelScope.launch {
            repository.deleteWork(id).onFailure {
                _message.value = it.message ?: "कामाची नोंद हटवता आली नाही."
            }
        }
    }

    fun clearMessage() {
        _message.value = null
    }
}
