package com.tractormanager.app.ui.screens.farmers

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tractormanager.app.core.Money
import com.tractormanager.app.ui.appViewModel
import com.tractormanager.app.ui.components.EmptyState
import com.tractormanager.app.ui.components.FarmerListCard
import com.tractormanager.app.ui.components.ScreenScaffold
import com.tractormanager.app.ui.theme.Border
import com.tractormanager.app.ui.theme.Green50
import com.tractormanager.app.ui.theme.Green700
import com.tractormanager.app.ui.theme.Green900
import com.tractormanager.app.ui.theme.InkSoft
import com.tractormanager.app.ui.theme.White

@Composable
fun FarmersScreen(
    onAddFarmer: () -> Unit,
    onFarmerClick: (String) -> Unit
) {
    val viewModel = appViewModel { FarmersViewModel(it.farmerRepository) }
    val farmers by viewModel.farmers.collectAsStateWithLifecycle()
    val totals by viewModel.totals.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }

    val filtered = remember(farmers, query) {
        val clean = query.trim()
        if (clean.isEmpty()) {
            farmers
        } else {
            farmers.filter {
                it.farmer.name.contains(clean, ignoreCase = true) ||
                    it.farmer.mobile.contains(clean) ||
                    it.farmer.village.contains(clean, ignoreCase = true)
            }
        }
    }

    ScreenScaffold(
        title = "शेतकरी",
        subtitle = "${farmers.size} शेतकरी नोंदवलेले",
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddFarmer,
                containerColor = Green700,
                contentColor = White,
                icon = { Icon(Icons.Outlined.Add, contentDescription = null) },
                text = { Text("शेतकरी जोडा") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Surface(
                    color = Green50,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                "एकूण वसूली बाकी",
                                style = MaterialTheme.typography.bodySmall,
                                color = InkSoft
                            )
                            Text(
                                Money.format(totals.pending),
                                style = MaterialTheme.typography.headlineSmall,
                                color = Green900
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                "शेतकरी",
                                style = MaterialTheme.typography.bodySmall,
                                color = InkSoft
                            )
                            Text(
                                totals.count.toString(),
                                style = MaterialTheme.typography.headlineSmall,
                                color = Green700
                            )
                        }
                    }
                }
            }
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("नाव, मोबाईल किंवा गाव शोधा") },
                    leadingIcon = {
                        Icon(Icons.Outlined.Search, contentDescription = null, tint = Green700)
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Green700,
                        unfocusedBorderColor = Border,
                        focusedContainerColor = White,
                        unfocusedContainerColor = White
                    )
                )
            }
            if (filtered.isEmpty()) {
                item {
                    if (farmers.isEmpty()) {
                        EmptyState(
                            title = "पहिला शेतकरी जोडा",
                            message = "नाव आणि मोबाईल नंबर नोंदवून शेतकऱ्याचे खाते सुरू करा.",
                            icon = Icons.Outlined.Groups,
                            actionLabel = "शेतकरी जोडा",
                            onAction = onAddFarmer
                        )
                    } else {
                        EmptyState(
                            title = "कोणी सापडले नाही",
                            message = "\"$query\" साठी जुळणारा शेतकरी नाही. दुसरे नाव किंवा नंबर वापरा.",
                            icon = Icons.Outlined.Search
                        )
                    }
                }
            } else {
                items(filtered, key = { it.farmer.id }) { item ->
                    FarmerListCard(
                        item = item,
                        onClick = { onFarmerClick(item.farmer.id) }
                    )
                }
            }
        }
    }
}
